using System;
using Dotnet4.0.Repositories;
using Dotnet4.0.Helpers;

namespace Dotnet4.0.Services
{
    public class AccountService
    {
        private readonly AccountRepository _accountRepository;
        private readonly EncryptionHelper _encryptionHelper;

        public AccountService(AccountRepository accountRepository, EncryptionHelper encryptionHelper)
        {
            _accountRepository = accountRepository;
            _encryptionHelper = encryptionHelper;
        }

        public bool LoginUser(string username, string password, bool rememberMe)
        {
            var encryptedPassword = _encryptionHelper.Encrypt(password);
            var isValidUser = _accountRepository.ValidateUserCredentials(username, encryptedPassword);

            if (isValidUser)
            {
                HandleRememberMe(username, rememberMe);
                return true;
            }

            return false;
        }

        public bool RegisterUser(string username, string password)
        {
            var encryptedPassword = _encryptionHelper.Encrypt(password);
            return _accountRepository.CreateUser(username, encryptedPassword);
        }

        public bool ForgotPassword(string username)
        {
            var user = _accountRepository.GetUserByUsername(username);
            if (user != null)
            {
                // Logic to initiate password reset process (e.g., sending a reset link via email)
                return true;
            }

            return false;
        }

        public bool ResetPassword(string username, string newPassword)
        {
            var encryptedPassword = _encryptionHelper.Encrypt(newPassword);
            return _accountRepository.UpdateUserPassword(username, encryptedPassword);
        }

        public bool ValidateUserCredentials(string username, string password)
        {
            var encryptedPassword = _encryptionHelper.Encrypt(password);
            return _accountRepository.ValidateUserCredentials(username, encryptedPassword);
        }

        public void HandleRememberMe(string username, bool rememberMe)
        {
            _accountRepository.UpdateRememberMe(username, rememberMe);
        }

        public string EncryptPassword(string password)
        {
            return _encryptionHelper.Encrypt(password);
        }

        public string DecryptPassword(string encryptedPassword)
        {
            return _encryptionHelper.Decrypt(encryptedPassword);
        }
    }
}
