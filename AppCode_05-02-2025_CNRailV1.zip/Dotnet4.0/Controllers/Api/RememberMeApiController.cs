using System;
using System.Web.Http;
using Dotnet4._0.Services;

namespace Dotnet4._0.Controllers.Api
{
    public class RememberMeApiController : ApiController
    {
        private readonly RememberMeService _rememberMeService;

        public RememberMeApiController()
        {
            _rememberMeService = new RememberMeService();
        }

        [HttpPost]
        [Route("api/rememberme")]
        public IHttpActionResult StoreCredentials([FromBody] RememberMeRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.Username) || string.IsNullOrEmpty(request.EncryptedPassword))
            {
                return BadRequest("Invalid request data.");
            }

            try
            {
                _rememberMeService.StoreCredentials(request.Username, request.EncryptedPassword);
                return Ok("Credentials stored successfully.");
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        [HttpGet]
        [Route("api/rememberme")]
        public IHttpActionResult RetrieveCredentials(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                return BadRequest("Username is required.");
            }

            try
            {
                var credentials = _rememberMeService.RetrieveCredentials(username);
                if (credentials == null)
                {
                    return NotFound();
                }

                return Ok(credentials);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        [HttpDelete]
        [Route("api/rememberme")]
        public IHttpActionResult ClearCredentials(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                return BadRequest("Username is required.");
            }

            try
            {
                _rememberMeService.ClearCredentials(username);
                return Ok("Credentials cleared successfully.");
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }
    }

    public class RememberMeRequest
    {
        public string Username { get; set; }
        public string EncryptedPassword { get; set; }
    }
}
