using System;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;

namespace Dotnet4._0.Helpers
{
    public static class XmlHelper
    {
        /// <summary>
        /// Reads an XML file from the specified path and returns the content as an XDocument.
        /// </summary>
        /// <param name="filePath">The path to the XML file.</param>
        /// <returns>The content of the XML file as an XDocument.</returns>
        public static XDocument ReadXmlFile(string filePath)
        {
            if (string.IsNullOrEmpty(filePath))
                throw new ArgumentException("File path cannot be null or empty.", nameof(filePath));

            try
            {
                return XDocument.Load(filePath);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Error reading XML file at {filePath}.", ex);
            }
        }

        /// <summary>
        /// Writes the given XDocument content to the specified XML file path.
        /// </summary>
        /// <param name="document">The XDocument content to write.</param>
        /// <param name="filePath">The path to the XML file.</param>
        public static void WriteXmlFile(XDocument document, string filePath)
        {
            if (document == null)
                throw new ArgumentNullException(nameof(document), "Document cannot be null.");

            if (string.IsNullOrEmpty(filePath))
                throw new ArgumentException("File path cannot be null or empty.", nameof(filePath));

            try
            {
                document.Save(filePath);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Error writing XML file to {filePath}.", ex);
            }
        }

        /// <summary>
        /// Validates the given XML content against the specified XML schema.
        /// </summary>
        /// <param name="xmlContent">The XML content to validate.</param>
        /// <param name="schemaPath">The path to the XML schema file.</param>
        /// <returns>True if the XML content is valid; otherwise, false.</returns>
        public static bool ValidateXml(string xmlContent, string schemaPath)
        {
            if (string.IsNullOrEmpty(xmlContent))
                throw new ArgumentException("XML content cannot be null or empty.", nameof(xmlContent));

            if (string.IsNullOrEmpty(schemaPath))
                throw new ArgumentException("Schema path cannot be null or empty.", nameof(schemaPath));

            try
            {
                XmlSchemaSet schemas = new XmlSchemaSet();
                schemas.Add(null, schemaPath);

                XDocument document = XDocument.Parse(xmlContent);
                bool isValid = true;
                document.Validate(schemas, (o, e) =>
                {
                    isValid = false;
                });

                return isValid;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Error validating XML content.", ex);
            }
        }

        /// <summary>
        /// Encrypts the given XML content.
        /// </summary>
        /// <param name="xmlContent">The XML content to encrypt.</param>
        /// <returns>The encrypted XML content.</returns>
        public static string EncryptXml(string xmlContent)
        {
            if (string.IsNullOrEmpty(xmlContent))
                throw new ArgumentException("XML content cannot be null or empty.", nameof(xmlContent));

            // Implement encryption logic here
            // For demonstration purposes, we'll just return the original content
            return xmlContent;
        }

        /// <summary>
        /// Decrypts the given encrypted XML content.
        /// </summary>
        /// <param name="encryptedXmlContent">The encrypted XML content to decrypt.</param>
        /// <returns>The decrypted XML content.</returns>
        public static string DecryptXml(string encryptedXmlContent)
        {
            if (string.IsNullOrEmpty(encryptedXmlContent))
                throw new ArgumentException("Encrypted XML content cannot be null or empty.", nameof(encryptedXmlContent));

            // Implement decryption logic here
            // For demonstration purposes, we'll just return the original content
            return encryptedXmlContent;
        }
    }
}
