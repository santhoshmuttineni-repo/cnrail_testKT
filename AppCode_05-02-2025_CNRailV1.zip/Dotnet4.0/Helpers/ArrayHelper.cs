using System;
using System.Collections.Generic;

namespace Dotnet4._0.Helpers
{
    public static class ArrayHelper
    {
        // Method to sort an array in ascending order
        public static void SortArray(int[] array)
        {
            Array.Sort(array);
        }

        // Method to search for an element in an array using binary search
        public static int BinarySearch(int[] array, int value)
        {
            return Array.BinarySearch(array, value);
        }

        // Method to reverse an array
        public static void ReverseArray(int[] array)
        {
            Array.Reverse(array);
        }

        // Method to find the maximum value in an array
        public static int FindMax(int[] array)
        {
            if (array == null || array.Length == 0)
                throw new ArgumentException("Array cannot be null or empty");

            int max = array[0];
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] > max)
                {
                    max = array[i];
                }
            }
            return max;
        }

        // Method to find the minimum value in an array
        public static int FindMin(int[] array)
        {
            if (array == null || array.Length == 0)
                throw new ArgumentException("Array cannot be null or empty");

            int min = array[0];
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] < min)
                {
                    min = array[i];
                }
            }
            return min;
        }

        // Method to calculate the sum of all elements in an array
        public static int SumArray(int[] array)
        {
            int sum = 0;
            for (int i = 0; i < array.Length; i++)
            {
                sum += array[i];
            }
            return sum;
        }

        // Method to calculate the average of all elements in an array
        public static double AverageArray(int[] array)
        {
            if (array == null || array.Length == 0)
                throw new ArgumentException("Array cannot be null or empty");

            int sum = SumArray(array);
            return (double)sum / array.Length;
        }

        // Method to check if an array contains a specific value
        public static bool ContainsValue(int[] array, int value)
        {
            foreach (int item in array)
            {
                if (item == value)
                {
                    return true;
                }
            }
            return false;
        }

        // Method to remove duplicates from an array
        public static int[] RemoveDuplicates(int[] array)
        {
            HashSet<int> set = new HashSet<int>(array);
            int[] result = new int[set.Count];
            set.CopyTo(result);
            return result;
        }

        // Method to merge two arrays into one
        public static int[] MergeArrays(int[] array1, int[] array2)
        {
            int[] mergedArray = new int[array1.Length + array2.Length];
            Array.Copy(array1, 0, mergedArray, 0, array1.Length);
            Array.Copy(array2, 0, mergedArray, array1.Length, array2.Length);
            return mergedArray;
        }
    }
}
