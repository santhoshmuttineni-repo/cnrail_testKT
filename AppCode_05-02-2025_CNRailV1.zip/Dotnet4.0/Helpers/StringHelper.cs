using System;
using System.Text.RegularExpressions;

namespace Dotnet4.0.Helpers
{
    public static class StringHelper
    {
        /// <summary>
        /// Validates if the input string is a valid email address.
        /// </summary>
        /// <param name="email">The email string to validate.</param>
        /// <returns>True if the email is valid, otherwise false.</returns>
        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                // Use IdnMapping class to convert Unicode domain names.
                email = Regex.Replace(email, @"(@)(.+)$", DomainMapper, RegexOptions.None, TimeSpan.FromMilliseconds(200));

                // Return true if strIn is in valid e-mail format.
                return Regex.IsMatch(email,
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                    RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
            catch (ArgumentException)
            {
                return false;
            }
        }

        private static string DomainMapper(Match match)
        {
            // Use IdnMapping class to convert Unicode domain names.
            var idn = new IdnMapping();

            string domainName = match.Groups[2].Value;
            try
            {
                domainName = idn.GetAscii(domainName);
            }
            catch (ArgumentException)
            {
                return string.Empty;
            }
            return match.Groups[1].Value + domainName;
        }

        /// <summary>
        /// Encrypts the input string using a simple encryption algorithm.
        /// </summary>
        /// <param name="input">The string to encrypt.</param>
        /// <returns>The encrypted string.</returns>
        public static string EncryptString(string input)
        {
            if (string.IsNullOrEmpty(input))
                return string.Empty;

            // Simple encryption logic (for demonstration purposes)
            char[] buffer = input.ToCharArray();
            for (int i = 0; i < buffer.Length; i++)
            {
                buffer[i] = (char)(buffer[i] + 1);
            }
            return new string(buffer);
        }

        /// <summary>
        /// Decrypts the input string using a simple decryption algorithm.
        /// </summary>
        /// <param name="input">The string to decrypt.</param>
        /// <returns>The decrypted string.</returns>
        public static string DecryptString(string input)
        {
            if (string.IsNullOrEmpty(input))
                return string.Empty;

            // Simple decryption logic (for demonstration purposes)
            char[] buffer = input.ToCharArray();
            for (int i = 0; i < buffer.Length; i++)
            {
                buffer[i] = (char)(buffer[i] - 1);
            }
            return new string(buffer);
        }

        /// <summary>
        /// Checks if the input string is null or empty.
        /// </summary>
        /// <param name="input">The string to check.</param>
        /// <returns>True if the string is null or empty, otherwise false.</returns>
        public static bool IsNullOrEmpty(string input)
        {
            return string.IsNullOrEmpty(input);
        }

        /// <summary>
        /// Formats the input string by trimming whitespace and converting to lowercase.
        /// </summary>
        /// <param name="input">The string to format.</param>
        /// <returns>The formatted string.</returns>
        public static string FormatString(string input)
        {
            if (string.IsNullOrEmpty(input))
                return string.Empty;

            return input.Trim().ToLower();
        }
    }
}
