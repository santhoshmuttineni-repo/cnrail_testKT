using System;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Security;

namespace Dotnet4._0.Helpers
{
    public static class TemplateMethodHelper
    {
        // Method to validate user input
        public static bool ValidateUserInput(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                return false;
            }

            // Additional validation logic can be added here
            return true;
        }

        // Method to handle 'Remember Me' functionality
        public static void HandleRememberMe(string username, string password, bool rememberMe)
        {
            if (rememberMe)
            {
                // Encrypt the credentials
                string encryptedUsername = Encrypt(username);
                string encryptedPassword = Encrypt(password);

                // Store the encrypted credentials in cookies
                HttpCookie usernameCookie = new HttpCookie("username", encryptedUsername);
                HttpCookie passwordCookie = new HttpCookie("password", encryptedPassword);

                usernameCookie.Expires = DateTime.Now.AddDays(30);
                passwordCookie.Expires = DateTime.Now.AddDays(30);

                HttpContext.Current.Response.Cookies.Add(usernameCookie);
                HttpContext.Current.Response.Cookies.Add(passwordCookie);
            }
        }

        // Method to ensure secure storage of login credentials
        public static void SecurelyStoreLoginCredentials(string username, string password)
        {
            // Encrypt the credentials
            string encryptedUsername = Encrypt(username);
            string encryptedPassword = Encrypt(password);

            // Store the encrypted credentials securely (e.g., in a database)
            // This is a placeholder for actual storage logic
            // StoreCredentialsInDatabase(encryptedUsername, encryptedPassword);
        }

        // Helper method to encrypt a string
        private static string Encrypt(string plainText)
        {
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
            byte[] encryptedBytes;

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes("A-16-Byte-Key123"); // Example key, should be securely stored
                aes.IV = Encoding.UTF8.GetBytes("A-16-Byte-IV1234"); // Example IV, should be securely stored

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
                encryptedBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
            }

            return Convert.ToBase64String(encryptedBytes);
        }

        // Helper method to decrypt a string
        private static string Decrypt(string encryptedText)
        {
            byte[] encryptedBytes = Convert.FromBase64String(encryptedText);
            byte[] plainBytes;

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes("A-16-Byte-Key123"); // Example key, should be securely stored
                aes.IV = Encoding.UTF8.GetBytes("A-16-Byte-IV1234"); // Example IV, should be securely stored

                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
                plainBytes = decryptor.TransformFinalBlock(encryptedBytes, 0, encryptedBytes.Length);
            }

            return Encoding.UTF8.GetString(plainBytes);
        }

        // Method to retrieve stored credentials (for demonstration purposes)
        public static (string username, string password) RetrieveStoredCredentials()
        {
            HttpCookie usernameCookie = HttpContext.Current.Request.Cookies["username"];
            HttpCookie passwordCookie = HttpContext.Current.Request.Cookies["password"];

            if (usernameCookie != null && passwordCookie != null)
            {
                string decryptedUsername = Decrypt(usernameCookie.Value);
                string decryptedPassword = Decrypt(passwordCookie.Value);

                return (decryptedUsername, decryptedPassword);
            }

            return (null, null);
        }
    }
}
