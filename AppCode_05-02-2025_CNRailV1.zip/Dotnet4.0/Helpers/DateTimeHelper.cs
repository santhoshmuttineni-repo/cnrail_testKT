using System;
using System.Globalization;

namespace Dotnet4.0.Helpers
{
    public static class DateTimeHelper
    {
        // Method to format DateTime to a specific string format
        public static string FormatDateTime(DateTime dateTime, string format)
        {
            return dateTime.ToString(format, CultureInfo.InvariantCulture);
        }

        // Method to calculate the difference in days between two dates
        public static int CalculateDateDifference(DateTime startDate, DateTime endDate)
        {
            return (endDate - startDate).Days;
        }

        // Method to convert DateTime from one time zone to another
        public static DateTime ConvertTimeZone(DateTime dateTime, string sourceTimeZoneId, string destinationTimeZoneId)
        {
            TimeZoneInfo sourceTimeZone = TimeZoneInfo.FindSystemTimeZoneById(sourceTimeZoneId);
            TimeZoneInfo destinationTimeZone = TimeZoneInfo.FindSystemTimeZoneById(destinationTimeZoneId);
            DateTime sourceTime = TimeZoneInfo.ConvertTime(dateTime, sourceTimeZone);
            DateTime destinationTime = TimeZoneInfo.ConvertTime(sourceTime, sourceTimeZone, destinationTimeZone);
            return destinationTime;
        }

        // Method to get the current DateTime in UTC
        public static DateTime GetCurrentUtcDateTime()
        {
            return DateTime.UtcNow;
        }

        // Method to parse a string to DateTime with a specific format
        public static DateTime ParseDateTime(string dateTimeString, string format)
        {
            return DateTime.ParseExact(dateTimeString, format, CultureInfo.InvariantCulture);
        }

        // Method to check if a given year is a leap year
        public static bool IsLeapYear(int year)
        {
            return DateTime.IsLeapYear(year);
        }

        // Method to add days to a given DateTime
        public static DateTime AddDays(DateTime dateTime, int days)
        {
            return dateTime.AddDays(days);
        }

        // Method to get the start of the week for a given DateTime
        public static DateTime GetStartOfWeek(DateTime dateTime, DayOfWeek startOfWeek)
        {
            int diff = (7 + (dateTime.DayOfWeek - startOfWeek)) % 7;
            return dateTime.AddDays(-1 * diff).Date;
        }

        // Method to get the end of the week for a given DateTime
        public static DateTime GetEndOfWeek(DateTime dateTime, DayOfWeek endOfWeek)
        {
            int diff = (7 - (endOfWeek - dateTime.DayOfWeek)) % 7;
            return dateTime.AddDays(diff).Date;
        }
    }
}
