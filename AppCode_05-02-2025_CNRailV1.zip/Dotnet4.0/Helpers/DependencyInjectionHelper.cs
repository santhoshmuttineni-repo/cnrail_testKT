using Microsoft.Extensions.DependencyInjection;
using System;

namespace Dotnet4._0.Helpers
{
    public static class DependencyInjectionHelper
    {
        public static void ConfigureServices(IServiceCollection services)
        {
            // Register application services
            services.AddTransient<IUserService, UserService>();
            services.AddTransient<IAuthenticationService, AuthenticationService>();
            services.AddTransient<IEncryptionService, EncryptionService>();

            // Register other dependencies
            services.AddSingleton<IConfiguration>(provider => 
            {
                var configurationBuilder = new ConfigurationBuilder()
                    .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
                return configurationBuilder.Build();
            });

            // Register database context
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            // Register other necessary services
            services.AddLogging();
            services.AddHttpClient();
        }
    }

    public interface IUserService
    {
        User GetUserByUsername(string username);
        void SaveUser(User user);
    }

    public class UserService : IUserService
    {
        private readonly ApplicationDbContext _context;

        public UserService(ApplicationDbContext context)
        {
            _context = context;
        }

        public User GetUserByUsername(string username)
        {
            return _context.Users.SingleOrDefault(u => u.Username == username);
        }

        public void SaveUser(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }
    }

    public interface IAuthenticationService
    {
        bool ValidateUser(string username, string password);
        void RememberUser(string username);
    }

    public class AuthenticationService : IAuthenticationService
    {
        private readonly IUserService _userService;
        private readonly IEncryptionService _encryptionService;

        public AuthenticationService(IUserService userService, IEncryptionService encryptionService)
        {
            _userService = userService;
            _encryptionService = encryptionService;
        }

        public bool ValidateUser(string username, string password)
        {
            var user = _userService.GetUserByUsername(username);
            if (user == null)
            {
                return false;
            }

            var encryptedPassword = _encryptionService.Encrypt(password);
            return user.Password == encryptedPassword;
        }

        public void RememberUser(string username)
        {
            var user = _userService.GetUserByUsername(username);
            if (user != null)
            {
                user.RememberMe = true;
                _userService.SaveUser(user);
            }
        }
    }

    public interface IEncryptionService
    {
        string Encrypt(string input);
        string Decrypt(string input);
    }

    public class EncryptionService : IEncryptionService
    {
        public string Encrypt(string input)
        {
            // Implement encryption logic here
            return Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(input));
        }

        public string Decrypt(string input)
        {
            // Implement decryption logic here
            return System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(input));
        }
    }

    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public bool RememberMe { get; set; }
    }

    public class ApplicationDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
    }
}
