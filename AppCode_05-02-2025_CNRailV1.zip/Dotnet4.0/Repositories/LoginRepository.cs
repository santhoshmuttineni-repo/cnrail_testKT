using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Data.Entity;

namespace Dotnet4.0.Repositories
{
    public class LoginRepository
    {
        private readonly MyDbContext _context;

        public LoginRepository(MyDbContext context)
        {
            _context = context;
        }

        public User GetUserByUsername(string username)
        {
            return _context.Users.SingleOrDefault(u => u.Username == username);
        }

        public bool ValidateUserCredentials(string username, string password)
        {
            var user = GetUserByUsername(username);
            if (user == null)
            {
                return false;
            }

            var hashedPassword = HashPassword(password);
            return user.Password == hashedPassword;
        }

        public void UpdateRememberMe(string username, bool rememberMe)
        {
            var user = GetUserByUsername(username);
            if (user != null)
            {
                user.RememberMe = rememberMe;
                _context.SaveChanges();
            }
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(password);
                var hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }
    }

    public class MyDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }
    }

    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public bool RememberMe { get; set; }
    }
}
