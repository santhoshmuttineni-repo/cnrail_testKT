using System;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Security;

namespace Dotnet4._0.Helpers
{
    public static class TaskHelper
    {
        // Encrypts the password using SHA256
        private static string EncryptPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        // Validates the user credentials
        public static bool ValidateUser(string username, string password)
        {
            // Fetch user from database (pseudo-code)
            var user = Database.GetUser(username);
            if (user == null)
            {
                return false;
            }

            // Compare encrypted passwords
            string encryptedPassword = EncryptPassword(password);
            return user.Password == encryptedPassword;
        }

        // Handles the "Remember Me" functionality
        public static void RememberMe(string username, bool rememberMe)
        {
            if (rememberMe)
            {
                HttpCookie authCookie = FormsAuthentication.GetAuthCookie(username, true);
                authCookie.Expires = DateTime.Now.AddDays(30); // Set cookie to expire in 30 days
                HttpContext.Current.Response.Cookies.Add(authCookie);
            }
        }

        // Logs the user in
        public static void LoginUser(string username, string password, bool rememberMe)
        {
            if (ValidateUser(username, password))
            {
                FormsAuthentication.SetAuthCookie(username, rememberMe);
                RememberMe(username, rememberMe);
            }
            else
            {
                throw new UnauthorizedAccessException("Invalid username or password.");
            }
        }

        // Logs the user out
        public static void LogoutUser()
        {
            FormsAuthentication.SignOut();
            HttpContext.Current.Session.Abandon();
            HttpCookie authCookie = HttpContext.Current.Request.Cookies[FormsAuthentication.FormsCookieName];
            if (authCookie != null)
            {
                authCookie.Expires = DateTime.Now.AddDays(-1);
                HttpContext.Current.Response.Cookies.Add(authCookie);
            }
        }

        // Securely stores login credentials
        public static void StoreCredentials(string username, string password)
        {
            string encryptedPassword = EncryptPassword(password);
            // Store encrypted password in database (pseudo-code)
            Database.StoreUserCredentials(username, encryptedPassword);
        }
    }
}
