using System;
using System.Collections.Generic;
using System.Linq;

namespace Dotnet4._0.Helpers
{
    public static class IteratorHelper
    {
        /// <summary>
        /// Iterates over a collection and performs an action on each element.
        /// </summary>
        /// <typeparam name="T">The type of elements in the collection.</typeparam>
        /// <param name="collection">The collection to iterate over.</param>
        /// <param name="action">The action to perform on each element.</param>
        public static void ForEach<T>(IEnumerable<T> collection, Action<T> action)
        {
            if (collection == null) throw new ArgumentNullException(nameof(collection));
            if (action == null) throw new ArgumentNullException(nameof(action));

            foreach (var item in collection)
            {
                action(item);
            }
        }

        /// <summary>
        /// Filters a collection based on a predicate.
        /// </summary>
        /// <typeparam name="T">The type of elements in the collection.</typeparam>
        /// <param name="collection">The collection to filter.</param>
        /// <param name="predicate">The predicate to filter by.</param>
        /// <returns>A filtered collection.</returns>
        public static IEnumerable<T> Filter<T>(IEnumerable<T> collection, Func<T, bool> predicate)
        {
            if (collection == null) throw new ArgumentNullException(nameof(collection));
            if (predicate == null) throw new ArgumentNullException(nameof(predicate));

            return collection.Where(predicate);
        }

        /// <summary>
        /// Maps a collection to a new form based on a selector function.
        /// </summary>
        /// <typeparam name="TSource">The type of elements in the source collection.</typeparam>
        /// <typeparam name="TResult">The type of elements in the result collection.</typeparam>
        /// <param name="collection">The collection to map.</param>
        /// <param name="selector">The selector function to map each element.</param>
        /// <returns>A collection of mapped elements.</returns>
        public static IEnumerable<TResult> Map<TSource, TResult>(IEnumerable<TSource> collection, Func<TSource, TResult> selector)
        {
            if (collection == null) throw new ArgumentNullException(nameof(collection));
            if (selector == null) throw new ArgumentNullException(nameof(selector));

            return collection.Select(selector);
        }

        /// <summary>
        /// Reduces a collection to a single value based on an accumulator function.
        /// </summary>
        /// <typeparam name="TSource">The type of elements in the collection.</typeparam>
        /// <typeparam name="TAccumulate">The type of the accumulated value.</typeparam>
        /// <param name="collection">The collection to reduce.</param>
        /// <param name="seed">The initial accumulated value.</param>
        /// <param name="func">The accumulator function.</param>
        /// <returns>The accumulated value.</returns>
        public static TAccumulate Reduce<TSource, TAccumulate>(IEnumerable<TSource> collection, TAccumulate seed, Func<TAccumulate, TSource, TAccumulate> func)
        {
            if (collection == null) throw new ArgumentNullException(nameof(collection));
            if (func == null) throw new ArgumentNullException(nameof(func));

            return collection.Aggregate(seed, func);
        }

        /// <summary>
        /// Checks if any element in the collection satisfies a predicate.
        /// </summary>
        /// <typeparam name="T">The type of elements in the collection.</typeparam>
        /// <param name="collection">The collection to check.</param>
        /// <param name="predicate">The predicate to check against.</param>
        /// <returns>True if any element satisfies the predicate, otherwise false.</returns>
        public static bool Any<T>(IEnumerable<T> collection, Func<T, bool> predicate)
        {
            if (collection == null) throw new ArgumentNullException(nameof(collection));
            if (predicate == null) throw new ArgumentNullException(nameof(predicate));

            return collection.Any(predicate);
        }

        /// <summary>
        /// Checks if all elements in the collection satisfy a predicate.
        /// </summary>
        /// <typeparam name="T">The type of elements in the collection.</typeparam>
        /// <param name="collection">The collection to check.</param>
        /// <param name="predicate">The predicate to check against.</param>
        /// <returns>True if all elements satisfy the predicate, otherwise false.</returns>
        public static bool All<T>(IEnumerable<T> collection, Func<T, bool> predicate)
        {
            if (collection == null) throw new ArgumentNullException(nameof(collection));
            if (predicate == null) throw new ArgumentNullException(nameof(predicate));

            return collection.All(predicate);
        }

        /// <summary>
        /// Finds the first element in the collection that satisfies a predicate.
        /// </summary>
        /// <typeparam name="T">The type of elements in the collection.</typeparam>
        /// <param name="collection">The collection to search.</param>
        /// <param name="predicate">The predicate to search by.</param>
        /// <returns>The first element that satisfies the predicate, or default if none found.</returns>
        public static T Find<T>(IEnumerable<T> collection, Func<T, bool> predicate)
        {
            if (collection == null) throw new ArgumentNullException(nameof(collection));
            if (predicate == null) throw new ArgumentNullException(nameof(predicate));

            return collection.FirstOrDefault(predicate);
        }

        /// <summary>
        /// Finds the index of the first element in the collection that satisfies a predicate.
        /// </summary>
        /// <typeparam name="T">The type of elements in the collection.</typeparam>
        /// <param name="collection">The collection to search.</param>
        /// <param name="predicate">The predicate to search by.</param>
        /// <returns>The index of the first element that satisfies the predicate, or -1 if none found.</returns>
        public static int FindIndex<T>(IEnumerable<T> collection, Func<T, bool> predicate)
        {
            if (collection == null) throw new ArgumentNullException(nameof(collection));
            if (predicate == null) throw new ArgumentNullException(nameof(predicate));

            int index = 0;
            foreach (var item in collection)
            {
                if (predicate(item))
                {
                    return index;
                }
                index++;
            }
            return -1;
        }
    }
}
