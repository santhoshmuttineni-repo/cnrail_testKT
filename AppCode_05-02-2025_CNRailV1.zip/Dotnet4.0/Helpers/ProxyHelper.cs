using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace Dotnet4._0.Helpers
{
    public static class ProxyHelper
    {
        private static readonly HttpClientHandler httpClientHandler = new HttpClientHandler();
        private static readonly HttpClient httpClient = new HttpClient(httpClientHandler);

        // Method to set proxy settings
        public static void SetProxy(string proxyUri, string username = null, string password = null)
        {
            if (string.IsNullOrEmpty(proxyUri))
            {
                throw new ArgumentException("Proxy URI cannot be null or empty", nameof(proxyUri));
            }

            var proxy = new WebProxy(proxyUri);

            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
            {
                proxy.Credentials = new NetworkCredential(username, password);
            }

            httpClientHandler.Proxy = proxy;
            httpClientHandler.UseProxy = true;
        }

        // Method to clear proxy settings
        public static void ClearProxy()
        {
            httpClientHandler.Proxy = null;
            httpClientHandler.UseProxy = false;
        }

        // Method to make a GET request through the proxy
        public static async Task<string> GetAsync(string requestUri)
        {
            if (string.IsNullOrEmpty(requestUri))
            {
                throw new ArgumentException("Request URI cannot be null or empty", nameof(requestUri));
            }

            var response = await httpClient.GetAsync(requestUri);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }

        // Method to make a POST request through the proxy
        public static async Task<string> PostAsync(string requestUri, HttpContent content)
        {
            if (string.IsNullOrEmpty(requestUri))
            {
                throw new ArgumentException("Request URI cannot be null or empty", nameof(requestUri));
            }

            var response = await httpClient.PostAsync(requestUri, content);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }

        // Method to make a PUT request through the proxy
        public static async Task<string> PutAsync(string requestUri, HttpContent content)
        {
            if (string.IsNullOrEmpty(requestUri))
            {
                throw new ArgumentException("Request URI cannot be null or empty", nameof(requestUri));
            }

            var response = await httpClient.PutAsync(requestUri, content);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }

        // Method to make a DELETE request through the proxy
        public static async Task<string> DeleteAsync(string requestUri)
        {
            if (string.IsNullOrEmpty(requestUri))
            {
                throw new ArgumentException("Request URI cannot be null or empty", nameof(requestUri));
            }

            var response = await httpClient.DeleteAsync(requestUri);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }
    }
}
