using System;
using System.Linq;
using System.Threading.Tasks;
using System.Data.Entity;
using Microsoft.AspNetCore.Identity;
using Dotnet4._0.Models;

namespace Dotnet4._0.Repositories
{
    public class UserRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly IPasswordHasher<User> _passwordHasher;

        public UserRepository(ApplicationDbContext context, IPasswordHasher<User> passwordHasher)
        {
            _context = context;
            _passwordHasher = passwordHasher;
        }

        public async Task<User> GetUserByUsername(string username)
        {
            return await _context.Users
                .FirstOrDefaultAsync(u => u.Username == username);
        }

        public async Task<bool> ValidateUserCredentials(string username, string password)
        {
            var user = await GetUserByUsername(username);
            if (user == null)
            {
                return false;
            }

            var passwordVerificationResult = _passwordHasher.VerifyHashedPassword(user, user.Password, password);
            return passwordVerificationResult == PasswordVerificationResult.Success;
        }

        public async Task UpdateRememberMe(string username, bool rememberMe)
        {
            var user = await GetUserByUsername(username);
            if (user != null)
            {
                user.RememberMe = rememberMe;
                _context.Entry(user).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
        }
    }
}
