using System;
using System.Web;
using System.Security.Cryptography;
using System.Text;

namespace Dotnet4._0.Helpers
{
    public static class CookieHelper
    {
        private static readonly string EncryptionKey = "YourEncryptionKey"; // Replace with your actual encryption key

        public static void SetCookie(string key, string value, DateTime expiry)
        {
            var encryptedValue = Encrypt(value);
            var cookie = new HttpCookie(key, encryptedValue)
            {
                Expires = expiry,
                HttpOnly = true,
                Secure = true
            };
            HttpContext.Current.Response.Cookies.Add(cookie);
        }

        public static string GetCookie(string key)
        {
            var cookie = HttpContext.Current.Request.Cookies[key];
            if (cookie != null)
            {
                var decryptedValue = Decrypt(cookie.Value);
                return decryptedValue;
            }
            return null;
        }

        public static void DeleteCookie(string key)
        {
            if (HttpContext.Current.Request.Cookies[key] != null)
            {
                var cookie = new HttpCookie(key)
                {
                    Expires = DateTime.Now.AddDays(-1)
                };
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
        }

        private static string Encrypt(string plainText)
        {
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
            using (Aes aes = Aes.Create())
            {
                var key = new Rfc2898DeriveBytes(EncryptionKey, Encoding.UTF8.GetBytes("SaltValue"));
                aes.Key = key.GetBytes(aes.KeySize / 8);
                aes.IV = key.GetBytes(aes.BlockSize / 8);

                using (var encryptor = aes.CreateEncryptor(aes.Key, aes.IV))
                {
                    byte[] encryptedBytes = PerformCryptography(plainBytes, encryptor);
                    return Convert.ToBase64String(encryptedBytes);
                }
            }
        }

        private static string Decrypt(string encryptedText)
        {
            byte[] encryptedBytes = Convert.FromBase64String(encryptedText);
            using (Aes aes = Aes.Create())
            {
                var key = new Rfc2898DeriveBytes(EncryptionKey, Encoding.UTF8.GetBytes("SaltValue"));
                aes.Key = key.GetBytes(aes.KeySize / 8);
                aes.IV = key.GetBytes(aes.BlockSize / 8);

                using (var decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
                {
                    byte[] decryptedBytes = PerformCryptography(encryptedBytes, decryptor);
                    return Encoding.UTF8.GetString(decryptedBytes);
                }
            }
        }

        private static byte[] PerformCryptography(byte[] data, ICryptoTransform cryptoTransform)
        {
            using (var memoryStream = new System.IO.MemoryStream())
            {
                using (var cryptoStream = new CryptoStream(memoryStream, cryptoTransform, CryptoStreamMode.Write))
                {
                    cryptoStream.Write(data, 0, data.Length);
                    cryptoStream.FlushFinalBlock();
                    return memoryStream.ToArray();
                }
            }
        }
    }
}
