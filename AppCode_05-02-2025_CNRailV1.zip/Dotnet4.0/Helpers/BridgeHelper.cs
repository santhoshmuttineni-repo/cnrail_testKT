using System;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Security;

namespace Dotnet4._0.Helpers
{
    public static class BridgeHelper
    {
        // Encrypts the password using SHA256
        public static string EncryptPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        // Validates the user credentials
        public static bool ValidateUser(string username, string password)
        {
            // This method should interact with the database to validate the user
            // For demonstration, let's assume a method GetUserFromDb(username) that fetches user details from the database
            var user = GetUserFromDb(username);
            if (user != null)
            {
                string encryptedPassword = EncryptPassword(password);
                return user.Password == encryptedPassword;
            }
            return false;
        }

        // Stores the user credentials securely if "Remember Me" is checked
        public static void RememberUser(string username, bool rememberMe)
        {
            if (rememberMe)
            {
                HttpCookie authCookie = FormsAuthentication.GetAuthCookie(username, true);
                authCookie.Expires = DateTime.Now.AddDays(30); // Set cookie to expire in 30 days
                HttpContext.Current.Response.Cookies.Add(authCookie);
            }
        }

        // Clears the stored user credentials
        public static void ClearRememberedUser()
        {
            HttpCookie authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, "")
            {
                Expires = DateTime.Now.AddYears(-1)
            };
            HttpContext.Current.Response.Cookies.Add(authCookie);
        }

        // Fetches user details from the database (dummy implementation)
        private static User GetUserFromDb(string username)
        {
            // This method should interact with the database to fetch user details
            // For demonstration, let's return a dummy user
            return new User
            {
                Username = "testuser",
                Password = EncryptPassword("testpassword"),
                RememberMe = true
            };
        }

        // Represents a user (dummy implementation)
        private class User
        {
            public string Username { get; set; }
            public string Password { get; set; }
            public bool RememberMe { get; set; }
        }
    }
}
