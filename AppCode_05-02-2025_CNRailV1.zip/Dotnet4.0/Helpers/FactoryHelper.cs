using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dotnet4.0.Helpers
{
    public static class FactoryHelper
    {
        // Method to create an instance of a user with encrypted credentials
        public static User CreateUser(string username, string password, bool rememberMe)
        {
            var encryptedPassword = EncryptPassword(password);
            return new User
            {
                Username = username,
                Password = encryptedPassword,
                RememberMe = rememberMe
            };
        }

        // Method to encrypt the password
        private static string EncryptPassword(string password)
        {
            // Implement encryption logic here
            // For demonstration, let's assume a simple base64 encoding
            var plainTextBytes = Encoding.UTF8.GetBytes(password);
            return Convert.ToBase64String(plainTextBytes);
        }

        // Method to validate user credentials
        public static bool ValidateUserCredentials(string username, string password)
        {
            // Fetch user from database
            var user = GetUserFromDatabase(username);
            if (user == null)
            {
                return false;
            }

            // Validate encrypted password
            var encryptedPassword = EncryptPassword(password);
            return user.Password == encryptedPassword;
        }

        // Method to fetch user from database
        private static User GetUserFromDatabase(string username)
        {
            // Implement database fetching logic here
            // For demonstration, let's assume a static user
            return new User
            {
                Username = "testUser",
                Password = EncryptPassword("testPassword"),
                RememberMe = true
            };
        }

        // Method to handle "Remember Me" functionality
        public static void HandleRememberMe(User user)
        {
            if (user.RememberMe)
            {
                // Implement logic to securely store user credentials
                // For demonstration, let's assume storing in a secure cookie
                StoreCredentialsInCookie(user);
            }
        }

        // Method to store credentials in a secure cookie
        private static void StoreCredentialsInCookie(User user)
        {
            // Implement cookie storage logic here
            // For demonstration, let's assume a simple console output
            Console.WriteLine($"Storing credentials for user: {user.Username}");
        }
    }

    // User class to represent user entity
    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public bool RememberMe { get; set; }
    }
}
