using System;
using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography;
using System.Text;

namespace Dotnet4._0.Models
{
    public class LoginForm
    {
        [Required(ErrorMessage = "Username is required.")]
        [Display(Name = "Username")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Display(Name = "Remember Me")]
        public bool RememberMe { get; set; }

        public bool Validate()
        {
            if (string.IsNullOrEmpty(Username))
            {
                throw new ValidationException("Username is required.");
            }

            if (string.IsNullOrEmpty(Password))
            {
                throw new ValidationException("Password is required.");
            }

            return true;
        }

        public void LogInformation()
        {
            Console.WriteLine($"Username: {Username}");
            Console.WriteLine($"Password: {Password}");
            Console.WriteLine($"Remember Me: {RememberMe}");
        }

        public string EncryptPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        public void StoreCredentials()
        {
            if (RememberMe)
            {
                // Securely store the credentials
                string encryptedPassword = EncryptPassword(Password);
                // Code to store the encrypted password and username securely
            }
        }
    }
}
