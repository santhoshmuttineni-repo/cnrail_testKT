using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dotnet4.0.Helpers
{
    public static class ParallelHelper
    {
        /// <summary>
        /// Executes a list of tasks in parallel and waits for all of them to complete.
        /// </summary>
        /// <param name="tasks">The list of tasks to execute.</param>
        public static void ExecuteTasksInParallel(List<Action> tasks)
        {
            if (tasks == null || tasks.Count == 0)
                throw new ArgumentException("Tasks cannot be null or empty");

            var taskList = tasks.Select(task => Task.Run(task)).ToArray();
            Task.WaitAll(taskList);
        }

        /// <summary>
        /// Executes a list of tasks in parallel and returns their results.
        /// </summary>
        /// <typeparam name="TResult">The type of the result produced by the tasks.</typeparam>
        /// <param name="tasks">The list of tasks to execute.</param>
        /// <returns>A list of results from the executed tasks.</returns>
        public static List<TResult> ExecuteTasksInParallel<TResult>(List<Func<TResult>> tasks)
        {
            if (tasks == null || tasks.Count == 0)
                throw new ArgumentException("Tasks cannot be null or empty");

            var taskList = tasks.Select(task => Task.Run(task)).ToArray();
            Task.WaitAll(taskList);

            return taskList.Select(t => t.Result).ToList();
        }

        /// <summary>
        /// Executes a list of tasks in parallel with a maximum degree of parallelism.
        /// </summary>
        /// <param name="tasks">The list of tasks to execute.</param>
        /// <param name="maxDegreeOfParallelism">The maximum number of tasks to run in parallel.</param>
        public static void ExecuteTasksInParallel(List<Action> tasks, int maxDegreeOfParallelism)
        {
            if (tasks == null || tasks.Count == 0)
                throw new ArgumentException("Tasks cannot be null or empty");

            if (maxDegreeOfParallelism <= 0)
                throw new ArgumentException("Max degree of parallelism must be greater than zero");

            var options = new ParallelOptions { MaxDegreeOfParallelism = maxDegreeOfParallelism };
            Parallel.ForEach(tasks, options, task => task());
        }

        /// <summary>
        /// Executes a list of tasks in parallel with a maximum degree of parallelism and returns their results.
        /// </summary>
        /// <typeparam name="TResult">The type of the result produced by the tasks.</typeparam>
        /// <param name="tasks">The list of tasks to execute.</param>
        /// <param name="maxDegreeOfParallelism">The maximum number of tasks to run in parallel.</param>
        /// <returns>A list of results from the executed tasks.</returns>
        public static List<TResult> ExecuteTasksInParallel<TResult>(List<Func<TResult>> tasks, int maxDegreeOfParallelism)
        {
            if (tasks == null || tasks.Count == 0)
                throw new ArgumentException("Tasks cannot be null or empty");

            if (maxDegreeOfParallelism <= 0)
                throw new ArgumentException("Max degree of parallelism must be greater than zero");

            var options = new ParallelOptions { MaxDegreeOfParallelism = maxDegreeOfParallelism };
            var results = new List<TResult>();

            Parallel.ForEach(tasks, options, task =>
            {
                var result = task();
                lock (results)
                {
                    results.Add(result);
                }
            });

            return results;
        }
    }
}
