using System.Web;
using System.Web.Mvc;

namespace Dotnet4._0.App_Start
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            // Adding a global error handler filter
            filters.Add(new HandleErrorAttribute());

            // Adding a global authorization filter
            filters.Add(new AuthorizeAttribute());

            // Adding a custom logging filter
            filters.Add(new CustomLoggingFilter());
        }
    }

    // Custom logging filter implementation
    public class CustomLoggingFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            // Log the details of the action being executed
            // This can be extended to log more details as required
            System.Diagnostics.Debug.WriteLine("Action Method Executing: " + filterContext.ActionDescriptor.ActionName);
            base.OnActionExecuting(filterContext);
        }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            // Log the details after the action has executed
            // This can be extended to log more details as required
            System.Diagnostics.Debug.WriteLine("Action Method Executed: " + filterContext.ActionDescriptor.ActionName);
            base.OnActionExecuted(filterContext);
        }
    }
}
