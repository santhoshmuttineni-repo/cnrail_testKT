using System;
using System.Net;
using System.Net.Mail;
using System.Configuration;

namespace Dotnet4._0.Helpers
{
    public static class EmailHelper
    {
        private static readonly string SmtpServer = ConfigurationManager.AppSettings["SmtpServer"];
        private static readonly int SmtpPort = int.Parse(ConfigurationManager.AppSettings["SmtpPort"]);
        private static readonly string SmtpUsername = ConfigurationManager.AppSettings["SmtpUsername"];
        private static readonly string SmtpPassword = ConfigurationManager.AppSettings["SmtpPassword"];
        private static readonly string FromEmail = ConfigurationManager.AppSettings["FromEmail"];

        public static void ConfigureEmailSettings()
        {
            // This method is used to configure email settings from the configuration file.
            // The settings are already loaded into static readonly fields.
        }

        public static MailMessage CreateEmailMessage(string toEmail, string subject, string body, bool isHtml = true)
        {
            var mailMessage = new MailMessage
            {
                From = new MailAddress(FromEmail),
                Subject = subject,
                Body = body,
                IsBodyHtml = isHtml
            };
            mailMessage.To.Add(toEmail);
            return mailMessage;
        }

        public static void SendEmail(MailMessage mailMessage)
        {
            using (var smtpClient = new SmtpClient(SmtpServer, SmtpPort))
            {
                smtpClient.Credentials = new NetworkCredential(SmtpUsername, SmtpPassword);
                smtpClient.EnableSsl = true;
                smtpClient.Send(mailMessage);
            }
        }

        public static void SendEmail(string toEmail, string subject, string body, bool isHtml = true)
        {
            var mailMessage = CreateEmailMessage(toEmail, subject, body, isHtml);
            SendEmail(mailMessage);
        }
    }
}
