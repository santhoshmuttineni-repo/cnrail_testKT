using System;
using System.Web;
using System.Web.Security;
using System.Security.Cryptography;
using System.Text;

namespace Dotnet4._0.Helpers
{
    public static class SessionHelper
    {
        private const string CookieName = "UserLoginCookie";
        private const string EncryptionKey = "YourEncryptionKey"; // Replace with your actual encryption key

        public static void CreateUserSession(string username, bool rememberMe)
        {
            HttpContext.Current.Session["Username"] = username;
            if (rememberMe)
            {
                CreateRememberMeCookie(username);
            }
        }

        public static void DestroyUserSession()
        {
            HttpContext.Current.Session.Clear();
            HttpContext.Current.Session.Abandon();
            RemoveRememberMeCookie();
        }

        public static string GetCurrentUser()
        {
            if (HttpContext.Current.Session["Username"] != null)
            {
                return HttpContext.Current.Session["Username"].ToString();
            }
            else if (HttpContext.Current.Request.Cookies[CookieName] != null)
            {
                var encryptedUsername = HttpContext.Current.Request.Cookies[CookieName].Value;
                var decryptedUsername = Decrypt(encryptedUsername);
                HttpContext.Current.Session["Username"] = decryptedUsername;
                return decryptedUsername;
            }
            return null;
        }

        private static void CreateRememberMeCookie(string username)
        {
            var encryptedUsername = Encrypt(username);
            var cookie = new HttpCookie(CookieName, encryptedUsername)
            {
                Expires = DateTime.Now.AddDays(30)
            };
            HttpContext.Current.Response.Cookies.Add(cookie);
        }

        private static void RemoveRememberMeCookie()
        {
            if (HttpContext.Current.Request.Cookies[CookieName] != null)
            {
                var cookie = new HttpCookie(CookieName)
                {
                    Expires = DateTime.Now.AddDays(-1)
                };
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
        }

        private static string Encrypt(string plainText)
        {
            var key = Encoding.UTF8.GetBytes(EncryptionKey);
            using (var aesAlg = Aes.Create())
            {
                using (var encryptor = aesAlg.CreateEncryptor(key, aesAlg.IV))
                {
                    using (var msEncrypt = new System.IO.MemoryStream())
                    {
                        msEncrypt.Write(aesAlg.IV, 0, aesAlg.IV.Length);
                        using (var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                        {
                            using (var swEncrypt = new System.IO.StreamWriter(csEncrypt))
                            {
                                swEncrypt.Write(plainText);
                            }
                        }
                        return Convert.ToBase64String(msEncrypt.ToArray());
                    }
                }
            }
        }

        private static string Decrypt(string cipherText)
        {
            var fullCipher = Convert.FromBase64String(cipherText);
            var iv = new byte[16];
            var cipher = new byte[16];

            Array.Copy(fullCipher, 0, iv, 0, iv.Length);
            Array.Copy(fullCipher, iv.Length, cipher, 0, iv.Length);

            var key = Encoding.UTF8.GetBytes(EncryptionKey);
            using (var aesAlg = Aes.Create())
            {
                using (var decryptor = aesAlg.CreateDecryptor(key, iv))
                {
                    using (var msDecrypt = new System.IO.MemoryStream(cipher))
                    {
                        using (var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                        {
                            using (var srDecrypt = new System.IO.StreamReader(csDecrypt))
                            {
                                return srDecrypt.ReadToEnd();
                            }
                        }
                    }
                }
            }
        }
    }
}
