using System;
using System.Collections.Generic;

namespace Dotnet4._0.Helpers
{
    public static class DictionaryHelper
    {
        /// <summary>
        /// Adds a key-value pair to the dictionary if the key does not already exist.
        /// </summary>
        /// <typeparam name="TKey">The type of the keys in the dictionary.</typeparam>
        /// <typeparam name="TValue">The type of the values in the dictionary.</typeparam>
        /// <param name="dictionary">The dictionary to add the key-value pair to.</param>
        /// <param name="key">The key to add.</param>
        /// <param name="value">The value to add.</param>
        /// <returns>True if the key-value pair was added, false if the key already exists.</returns>
        public static bool AddIfNotExists<TKey, TValue>(this IDictionary<TKey, TValue> dictionary, TKey key, TValue value)
        {
            if (!dictionary.ContainsKey(key))
            {
                dictionary.Add(key, value);
                return true;
            }
            return false;
        }

        /// <summary>
        /// Removes a key-value pair from the dictionary if the key exists.
        /// </summary>
        /// <typeparam name="TKey">The type of the keys in the dictionary.</typeparam>
        /// <typeparam name="TValue">The type of the values in the dictionary.</typeparam>
        /// <param name="dictionary">The dictionary to remove the key-value pair from.</param>
        /// <param name="key">The key to remove.</param>
        /// <returns>True if the key-value pair was removed, false if the key does not exist.</returns>
        public static bool RemoveIfExists<TKey, TValue>(this IDictionary<TKey, TValue> dictionary, TKey key)
        {
            if (dictionary.ContainsKey(key))
            {
                dictionary.Remove(key);
                return true;
            }
            return false;
        }

        /// <summary>
        /// Retrieves the value associated with the specified key, or the default value if the key does not exist.
        /// </summary>
        /// <typeparam name="TKey">The type of the keys in the dictionary.</typeparam>
        /// <typeparam name="TValue">The type of the values in the dictionary.</typeparam>
        /// <param name="dictionary">The dictionary to retrieve the value from.</param>
        /// <param name="key">The key whose value to retrieve.</param>
        /// <param name="defaultValue">The default value to return if the key does not exist.</param>
        /// <returns>The value associated with the specified key, or the default value if the key does not exist.</returns>
        public static TValue GetValueOrDefault<TKey, TValue>(this IDictionary<TKey, TValue> dictionary, TKey key, TValue defaultValue = default(TValue))
        {
            if (dictionary.TryGetValue(key, out TValue value))
            {
                return value;
            }
            return defaultValue;
        }

        /// <summary>
        /// Updates the value associated with the specified key if the key exists.
        /// </summary>
        /// <typeparam name="TKey">The type of the keys in the dictionary.</typeparam>
        /// <typeparam name="TValue">The type of the values in the dictionary.</typeparam>
        /// <param name="dictionary">The dictionary to update the value in.</param>
        /// <param name="key">The key whose value to update.</param>
        /// <param name="newValue">The new value to set.</param>
        /// <returns>True if the value was updated, false if the key does not exist.</returns>
        public static bool UpdateIfExists<TKey, TValue>(this IDictionary<TKey, TValue> dictionary, TKey key, TValue newValue)
        {
            if (dictionary.ContainsKey(key))
            {
                dictionary[key] = newValue;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Merges the source dictionary into the target dictionary. If a key exists in both dictionaries, the value from the source dictionary will overwrite the value in the target dictionary.
        /// </summary>
        /// <typeparam name="TKey">The type of the keys in the dictionaries.</typeparam>
        /// <typeparam name="TValue">The type of the values in the dictionaries.</typeparam>
        /// <param name="target">The target dictionary to merge into.</param>
        /// <param name="source">The source dictionary to merge from.</param>
        public static void MergeDictionaries<TKey, TValue>(this IDictionary<TKey, TValue> target, IDictionary<TKey, TValue> source)
        {
            foreach (var kvp in source)
            {
                target[kvp.Key] = kvp.Value;
            }
        }
    }
}
