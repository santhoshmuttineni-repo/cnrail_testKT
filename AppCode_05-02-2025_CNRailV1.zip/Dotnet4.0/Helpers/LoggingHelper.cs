using System;
using System.IO;
using log4net;
using log4net.Config;
using Newtonsoft.Json;

namespace Dotnet4.0.Helpers
{
    public static class LoggingHelper
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(LoggingHelper));

        static LoggingHelper()
        {
            XmlConfigurator.Configure(new FileInfo("log4net.config"));
        }

        public static void LogAction(string action, string details)
        {
            try
            {
                var logEntry = new
                {
                    Timestamp = DateTime.UtcNow,
                    Action = action,
                    Details = details
                };

                string logMessage = JsonConvert.SerializeObject(logEntry);
                log.Info(logMessage);
            }
            catch (Exception ex)
            {
                log.Error("Failed to log action", ex);
            }
        }
    }
}
