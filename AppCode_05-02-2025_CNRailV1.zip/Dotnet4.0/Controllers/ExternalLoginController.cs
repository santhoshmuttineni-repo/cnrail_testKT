using System;
using System.Web.Mvc;
using System.Web.Security;
using Dotnet4._0.Models;
using Dotnet4._0.Services;

namespace Dotnet4._0.Controllers
{
    public class ExternalLoginController : Controller
    {
        private readonly IUserService _userService;
        private readonly IAuthenticationService _authenticationService;

        public ExternalLoginController(IUserService userService, IAuthenticationService authenticationService)
        {
            _userService = userService;
            _authenticationService = authenticationService;
        }

        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginViewModel model, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                var user = _userService.ValidateUser(model.Username, model.Password);
                if (user != null)
                {
                    _authenticationService.SignIn(user, model.RememberMe);
                    return RedirectToLocal(returnUrl);
                }
                else
                {
                    ModelState.AddModelError("", "Invalid username or password.");
                }
            }
            return View(model);
        }

        [HttpPost]
        public ActionResult LogOff()
        {
            _authenticationService.SignOut();
            return RedirectToAction("Index", "Home");
        }

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }
    }
}

namespace Dotnet4._0.Models
{
    public class LoginViewModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public bool RememberMe { get; set; }
    }
}

namespace Dotnet4._0.Services
{
    public interface IUserService
    {
        User ValidateUser(string username, string password);
    }

    public interface IAuthenticationService
    {
        void SignIn(User user, bool isPersistent);
        void SignOut();
    }

    public class UserService : IUserService
    {
        public User ValidateUser(string username, string password)
        {
            // Implement user validation logic here
            // This is a placeholder implementation
            if (username == "test" && password == "password")
            {
                return new User { Username = username };
            }
            return null;
        }
    }

    public class AuthenticationService : IAuthenticationService
    {
        public void SignIn(User user, bool isPersistent)
        {
            FormsAuthentication.SetAuthCookie(user.Username, isPersistent);
        }

        public void SignOut()
        {
            FormsAuthentication.SignOut();
        }
    }

    public class User
    {
        public string Username { get; set; }
    }
}
