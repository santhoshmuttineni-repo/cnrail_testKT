using System;

namespace Dotnet4.0.Helpers
{
    public static class BooleanHelper
    {
        /// <summary>
        /// Checks if the provided string is null or empty.
        /// </summary>
        /// <param name="input">The string to check.</param>
        /// <returns>True if the string is null or empty, otherwise false.</returns>
        public static bool IsNullOrEmpty(string input)
        {
            return string.IsNullOrEmpty(input);
        }

        /// <summary>
        /// Checks if the provided string is null, empty, or consists only of white-space characters.
        /// </summary>
        /// <param name="input">The string to check.</param>
        /// <returns>True if the string is null, empty, or consists only of white-space characters, otherwise false.</returns>
        public static bool IsNullOrWhiteSpace(string input)
        {
            return string.IsNullOrWhiteSpace(input);
        }

        /// <summary>
        /// Converts a string to a boolean value.
        /// </summary>
        /// <param name="input">The string to convert.</param>
        /// <returns>True if the string represents a true value, otherwise false.</returns>
        public static bool ToBoolean(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return false;
            }

            bool result;
            if (bool.TryParse(input, out result))
            {
                return result;
            }

            return false;
        }

        /// <summary>
        /// Negates the provided boolean value.
        /// </summary>
        /// <param name="input">The boolean value to negate.</param>
        /// <returns>The negated boolean value.</returns>
        public static bool Negate(bool input)
        {
            return !input;
        }

        /// <summary>
        /// Performs a logical AND operation on two boolean values.
        /// </summary>
        /// <param name="input1">The first boolean value.</param>
        /// <param name="input2">The second boolean value.</param>
        /// <returns>The result of the logical AND operation.</returns>
        public static bool And(bool input1, bool input2)
        {
            return input1 && input2;
        }

        /// <summary>
        /// Performs a logical OR operation on two boolean values.
        /// </summary>
        /// <param name="input1">The first boolean value.</param>
        /// <param name="input2">The second boolean value.</param>
        /// <returns>The result of the logical OR operation.</returns>
        public static bool Or(bool input1, bool input2)
        {
            return input1 || input2;
        }

        /// <summary>
        /// Performs a logical XOR operation on two boolean values.
        /// </summary>
        /// <param name="input1">The first boolean value.</param>
        /// <param name="input2">The second boolean value.</param>
        /// <returns>The result of the logical XOR operation.</returns>
        public static bool Xor(bool input1, bool input2)
        {
            return input1 ^ input2;
        }

        /// <summary>
        /// Checks if the provided boolean value is true.
        /// </summary>
        /// <param name="input">The boolean value to check.</param>
        /// <returns>True if the boolean value is true, otherwise false.</returns>
        public static bool IsTrue(bool input)
        {
            return input;
        }

        /// <summary>
        /// Checks if the provided boolean value is false.
        /// </summary>
        /// <param name="input">The boolean value to check.</param>
        /// <returns>True if the boolean value is false, otherwise false.</returns>
        public static bool IsFalse(bool input)
        {
            return !input;
        }
    }
}
