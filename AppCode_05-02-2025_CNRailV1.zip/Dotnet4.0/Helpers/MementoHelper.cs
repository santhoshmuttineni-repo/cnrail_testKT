using System;
using System.Security.Cryptography;
using System.Text;
using System.IO;

namespace Dotnet4._0.Helpers
{
    public static class MementoHelper
    {
        private static readonly string EncryptionKey = "your-encryption-key"; // Replace with a secure key

        public static void StoreCredentials(string username, string password, bool rememberMe)
        {
            if (rememberMe)
            {
                string encryptedUsername = Encrypt(username);
                string encryptedPassword = Encrypt(password);

                // Store encrypted credentials securely
                // This is a placeholder for actual storage logic, e.g., writing to a secure file or database
                File.WriteAllText("username.txt", encryptedUsername);
                File.WriteAllText("password.txt", encryptedPassword);
            }
        }

        public static (string username, string password) RetrieveCredentials()
        {
            // This is a placeholder for actual retrieval logic, e.g., reading from a secure file or database
            if (File.Exists("username.txt") && File.Exists("password.txt"))
            {
                string encryptedUsername = File.ReadAllText("username.txt");
                string encryptedPassword = File.ReadAllText("password.txt");

                string username = Decrypt(encryptedUsername);
                string password = Decrypt(encryptedPassword);

                return (username, password);
            }

            return (null, null);
        }

        private static string Encrypt(string plainText)
        {
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(EncryptionKey);
                aes.IV = new byte[16]; // Initialization vector with zeros

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(plainBytes, 0, plainBytes.Length);
                        cs.Close();
                    }
                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }

        private static string Decrypt(string encryptedText)
        {
            byte[] encryptedBytes = Convert.FromBase64String(encryptedText);
            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(EncryptionKey);
                aes.IV = new byte[16]; // Initialization vector with zeros

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(encryptedBytes, 0, encryptedBytes.Length);
                        cs.Close();
                    }
                    return Encoding.UTF8.GetString(ms.ToArray());
                }
            }
        }
    }
}
