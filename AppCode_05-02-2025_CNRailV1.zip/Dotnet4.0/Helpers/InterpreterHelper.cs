using System;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace Dotnet4.0.Helpers
{
    public static class InterpreterHelper
    {
        // Method to validate the username
        public static bool ValidateUsername(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                return false;
            }

            // Username must be between 3 and 20 characters and contain only alphanumeric characters
            var regex = new Regex("^[a-zA-Z0-9]{3,20}$");
            return regex.IsMatch(username);
        }

        // Method to validate the password
        public static bool ValidatePassword(string password)
        {
            if (string.IsNullOrEmpty(password))
            {
                return false;
            }

            // Password must be at least 8 characters long and contain at least one number and one special character
            var regex = new Regex("^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,}$");
            return regex.IsMatch(password);
        }

        // Method to encrypt the password
        public static string EncryptPassword(string password)
        {
            if (string.IsNullOrEmpty(password))
            {
                throw new ArgumentNullException(nameof(password));
            }

            using (var sha256 = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(password);
                var hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }

        // Method to securely store login credentials
        public static void StoreCredentials(string username, string encryptedPassword, bool rememberMe)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(encryptedPassword))
            {
                throw new ArgumentNullException("Username and encrypted password cannot be null or empty.");
            }

            // Logic to store credentials securely, e.g., in a database or secure storage
            // This is a placeholder for actual storage logic
            // Example: Database.SaveUserCredentials(username, encryptedPassword, rememberMe);
        }

        // Method to check if the user is remembered
        public static bool IsUserRemembered(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                throw new ArgumentNullException(nameof(username));
            }

            // Logic to check if the user is remembered
            // This is a placeholder for actual check logic
            // Example: return Database.IsUserRemembered(username);
            return false;
        }

        // Method to clear stored credentials
        public static void ClearStoredCredentials(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                throw new ArgumentNullException(nameof(username));
            }

            // Logic to clear stored credentials
            // This is a placeholder for actual clear logic
            // Example: Database.ClearUserCredentials(username);
        }
    }
}
