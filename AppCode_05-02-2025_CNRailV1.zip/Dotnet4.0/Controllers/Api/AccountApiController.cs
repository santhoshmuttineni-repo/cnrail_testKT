using System;
using System.Web.Http;
using Dotnet4._0.Services;

namespace Dotnet4._0.Controllers.Api
{
    public class AccountApiController : ApiController
    {
        private readonly AccountService _accountService;

        public AccountApiController()
        {
            _accountService = new AccountService();
        }

        [HttpPost]
        [Route("api/account/login")]
        public IHttpActionResult Login(LoginRequest loginRequest)
        {
            if (loginRequest == null || string.IsNullOrEmpty(loginRequest.Username) || string.IsNullOrEmpty(loginRequest.Password))
            {
                return BadRequest("Username and password are required.");
            }

            var encryptedPassword = _accountService.EncryptPassword(loginRequest.Password);
            var isValidUser = _accountService.ValidateUserCredentials(loginRequest.Username, encryptedPassword);

            if (!isValidUser)
            {
                return Unauthorized();
            }

            _accountService.HandleRememberMe(loginRequest.Username, loginRequest.RememberMe);

            return Ok("Login successful.");
        }
    }

    public class LoginRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public bool RememberMe { get; set; }
    }
}
