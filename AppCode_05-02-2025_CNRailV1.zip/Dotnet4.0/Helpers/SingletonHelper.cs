using System;

namespace Dotnet4._0.Helpers
{
    public sealed class SingletonHelper
    {
        private static readonly Lazy<SingletonHelper> instance = new Lazy<SingletonHelper>(() => new SingletonHelper());

        // Private constructor to prevent instantiation from outside
        private SingletonHelper()
        {
            // Initialize any shared resources or configurations here
        }

        // Public property to provide global access to the instance
        public static SingletonHelper Instance
        {
            get
            {
                return instance.Value;
            }
        }

        // Example method to demonstrate functionality
        public void DoSomething()
        {
            // Implement the logic for the method here
        }
    }
}
