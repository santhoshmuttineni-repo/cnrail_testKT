using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace Dotnet4._0.Repositories
{
    public class AccountRepository
    {
        private readonly string _connectionString;

        public AccountRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<User> GetUserByUsername(string username)
        {
            using (var context = new UserDbContext(_connectionString))
            {
                return await context.Users.FirstOrDefaultAsync(u => u.Username == username);
            }
        }

        public async Task<bool> ValidateUserCredentials(string username, string password)
        {
            using (var context = new UserDbContext(_connectionString))
            {
                var user = await context.Users.FirstOrDefaultAsync(u => u.Username == username);
                if (user == null)
                {
                    return false;
                }

                var hashedPassword = HashPassword(password);
                return user.Password == hashedPassword;
            }
        }

        public async Task UpdateRememberMe(string username, bool rememberMe)
        {
            using (var context = new UserDbContext(_connectionString))
            {
                var user = await context.Users.FirstOrDefaultAsync(u => u.Username == username);
                if (user != null)
                {
                    user.RememberMe = rememberMe;
                    await context.SaveChangesAsync();
                }
            }
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(password);
                var hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }
    }

    public class UserDbContext : DbContext
    {
        public UserDbContext(string connectionString) : base(connectionString)
        {
        }

        public DbSet<User> Users { get; set; }
    }

    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public bool RememberMe { get; set; }
    }
}
