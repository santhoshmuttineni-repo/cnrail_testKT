using System;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Security;

namespace Dotnet4.0.Helpers
{
    public static class PrototypeHelper
    {
        // Method to validate user input
        public static bool ValidateUserInput(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                return false;
            }
            return true;
        }

        // Method to encrypt the password
        public static string EncryptPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(password);
                var hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }

        // Method to securely store login credentials
        public static void StoreLoginCredentials(string username, string encryptedPassword, bool rememberMe)
        {
            if (rememberMe)
            {
                HttpCookie cookie = new HttpCookie("UserLogin");
                cookie.Values["Username"] = username;
                cookie.Values["Password"] = encryptedPassword;
                cookie.Expires = DateTime.Now.AddDays(30);
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
            else
            {
                FormsAuthentication.SetAuthCookie(username, false);
            }
        }

        // Method to manage user sessions
        public static void ManageUserSession(string username)
        {
            FormsAuthentication.SetAuthCookie(username, true);
        }

        // Method to check if user is remembered
        public static bool IsUserRemembered()
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies["UserLogin"];
            return cookie != null;
        }

        // Method to get remembered user credentials
        public static (string username, string password) GetRememberedUserCredentials()
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies["UserLogin"];
            if (cookie != null)
            {
                string username = cookie.Values["Username"];
                string password = cookie.Values["Password"];
                return (username, password);
            }
            return (null, null);
        }

        // Method to clear remembered user credentials
        public static void ClearRememberedUserCredentials()
        {
            HttpCookie cookie = new HttpCookie("UserLogin");
            cookie.Expires = DateTime.Now.AddDays(-1);
            HttpContext.Current.Response.Cookies.Add(cookie);
        }
    }
}
