using Newtonsoft.Json;
using System;
using System.IO;

namespace Dotnet4.0.Helpers
{
    public static class JsonHelper
    {
        /// <summary>
        /// Serializes an object to a JSON string.
        /// </summary>
        /// <typeparam name="T">The type of the object to serialize.</typeparam>
        /// <param name="obj">The object to serialize.</param>
        /// <returns>A JSON string representation of the object.</returns>
        public static string SerializeObject<T>(T obj)
        {
            return JsonConvert.SerializeObject(obj);
        }

        /// <summary>
        /// Deserializes a JSON string to an object of type T.
        /// </summary>
        /// <typeparam name="T">The type of the object to deserialize to.</typeparam>
        /// <param name="json">The JSON string to deserialize.</param>
        /// <returns>An object of type T.</returns>
        public static T DeserializeObject<T>(string json)
        {
            return JsonConvert.DeserializeObject<T>(json);
        }

        /// <summary>
        /// Serializes an object to a JSON string and writes it to a file.
        /// </summary>
        /// <typeparam name="T">The type of the object to serialize.</typeparam>
        /// <param name="obj">The object to serialize.</param>
        /// <param name="filePath">The file path to write the JSON string to.</param>
        public static void SerializeObjectToFile<T>(T obj, string filePath)
        {
            string json = SerializeObject(obj);
            File.WriteAllText(filePath, json);
        }

        /// <summary>
        /// Deserializes a JSON string from a file to an object of type T.
        /// </summary>
        /// <typeparam name="T">The type of the object to deserialize to.</typeparam>
        /// <param name="filePath">The file path to read the JSON string from.</param>
        /// <returns>An object of type T.</returns>
        public static T DeserializeObjectFromFile<T>(string filePath)
        {
            string json = File.ReadAllText(filePath);
            return DeserializeObject<T>(json);
        }
    }
}
