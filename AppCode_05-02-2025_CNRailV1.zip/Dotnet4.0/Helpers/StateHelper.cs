using System;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Security;

namespace Dotnet4._0.Helpers
{
    public static class StateHelper
    {
        private const string CookieName = "UserLoginCookie";
        private const string EncryptionKey = "YourEncryptionKey"; // Replace with your actual encryption key

        public static void SetUserLoginState(string username, string password, bool rememberMe)
        {
            var encryptedUsername = Encrypt(username);
            var encryptedPassword = Encrypt(password);

            var authTicket = new FormsAuthenticationTicket(
                1,
                encryptedUsername,
                DateTime.Now,
                rememberMe ? DateTime.Now.AddDays(30) : DateTime.Now.AddMinutes(30),
                rememberMe,
                encryptedPassword
            );

            var encryptedTicket = FormsAuthentication.Encrypt(authTicket);
            var authCookie = new HttpCookie(CookieName, encryptedTicket)
            {
                HttpOnly = true,
                Secure = FormsAuthentication.RequireSSL,
                Expires = rememberMe ? DateTime.Now.AddDays(30) : DateTime.Now.AddMinutes(30)
            };

            HttpContext.Current.Response.Cookies.Add(authCookie);
        }

        public static bool IsUserLoggedIn()
        {
            var authCookie = HttpContext.Current.Request.Cookies[CookieName];
            if (authCookie == null)
            {
                return false;
            }

            try
            {
                var authTicket = FormsAuthentication.Decrypt(authCookie.Value);
                if (authTicket == null || authTicket.Expired)
                {
                    return false;
                }

                var decryptedUsername = Decrypt(authTicket.Name);
                var decryptedPassword = Decrypt(authTicket.UserData);

                // Validate the decrypted credentials with the database or any other storage
                return ValidateUserCredentials(decryptedUsername, decryptedPassword);
            }
            catch
            {
                return false;
            }
        }

        public static void LogoutUser()
        {
            var authCookie = new HttpCookie(CookieName)
            {
                Expires = DateTime.Now.AddDays(-1),
                HttpOnly = true,
                Secure = FormsAuthentication.RequireSSL
            };

            HttpContext.Current.Response.Cookies.Add(authCookie);
            FormsAuthentication.SignOut();
        }

        private static string Encrypt(string plainText)
        {
            using (var aes = Aes.Create())
            {
                var key = Encoding.UTF8.GetBytes(EncryptionKey);
                var iv = new byte[16];
                using (var encryptor = aes.CreateEncryptor(key, iv))
                {
                    var plainBytes = Encoding.UTF8.GetBytes(plainText);
                    var encryptedBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
                    return Convert.ToBase64String(encryptedBytes);
                }
            }
        }

        private static string Decrypt(string encryptedText)
        {
            using (var aes = Aes.Create())
            {
                var key = Encoding.UTF8.GetBytes(EncryptionKey);
                var iv = new byte[16];
                using (var decryptor = aes.CreateDecryptor(key, iv))
                {
                    var encryptedBytes = Convert.FromBase64String(encryptedText);
                    var decryptedBytes = decryptor.TransformFinalBlock(encryptedBytes, 0, encryptedBytes.Length);
                    return Encoding.UTF8.GetString(decryptedBytes);
                }
            }
        }

        private static bool ValidateUserCredentials(string username, string password)
        {
            // Implement the logic to validate the user credentials with the database or any other storage
            // This is a placeholder implementation and should be replaced with actual validation logic
            return true;
        }
    }
}
