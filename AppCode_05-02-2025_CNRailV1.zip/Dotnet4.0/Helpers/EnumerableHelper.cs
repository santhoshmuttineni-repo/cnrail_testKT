using System;
using System.Collections.Generic;
using System.Linq;

namespace Dotnet4._0.Helpers
{
    public static class EnumerableHelper
    {
        /// <summary>
        /// Filters a collection based on a predicate.
        /// </summary>
        /// <typeparam name="T">The type of the elements in the collection.</typeparam>
        /// <param name="source">The collection to filter.</param>
        /// <param name="predicate">The predicate to filter the collection.</param>
        /// <returns>A filtered collection.</returns>
        public static IEnumerable<T> Filter<T>(IEnumerable<T> source, Func<T, bool> predicate)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (predicate == null) throw new ArgumentNullException(nameof(predicate));

            return source.Where(predicate);
        }

        /// <summary>
        /// Sorts a collection based on a key selector.
        /// </summary>
        /// <typeparam name="TSource">The type of the elements in the collection.</typeparam>
        /// <typeparam name="TKey">The type of the key to sort by.</typeparam>
        /// <param name="source">The collection to sort.</param>
        /// <param name="keySelector">The key selector to sort the collection.</param>
        /// <param name="ascending">Whether to sort in ascending order.</param>
        /// <returns>A sorted collection.</returns>
        public static IEnumerable<TSource> Sort<TSource, TKey>(IEnumerable<TSource> source, Func<TSource, TKey> keySelector, bool ascending = true)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (keySelector == null) throw new ArgumentNullException(nameof(keySelector));

            return ascending ? source.OrderBy(keySelector) : source.OrderByDescending(keySelector);
        }

        /// <summary>
        /// Transforms a collection based on a selector.
        /// </summary>
        /// <typeparam name="TSource">The type of the elements in the source collection.</typeparam>
        /// <typeparam name="TResult">The type of the elements in the result collection.</typeparam>
        /// <param name="source">The collection to transform.</param>
        /// <param name="selector">The selector to transform the collection.</param>
        /// <returns>A transformed collection.</returns>
        public static IEnumerable<TResult> Transform<TSource, TResult>(IEnumerable<TSource> source, Func<TSource, TResult> selector)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (selector == null) throw new ArgumentNullException(nameof(selector));

            return source.Select(selector);
        }

        /// <summary>
        /// Paginates a collection.
        /// </summary>
        /// <typeparam name="T">The type of the elements in the collection.</typeparam>
        /// <param name="source">The collection to paginate.</param>
        /// <param name="pageNumber">The page number to retrieve.</param>
        /// <param name="pageSize">The size of the page.</param>
        /// <returns>A paginated collection.</returns>
        public static IEnumerable<T> Paginate<T>(IEnumerable<T> source, int pageNumber, int pageSize)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (pageNumber < 1) throw new ArgumentOutOfRangeException(nameof(pageNumber));
            if (pageSize < 1) throw new ArgumentOutOfRangeException(nameof(pageSize));

            return source.Skip((pageNumber - 1) * pageSize).Take(pageSize);
        }

        /// <summary>
        /// Groups a collection by a key selector.
        /// </summary>
        /// <typeparam name="TSource">The type of the elements in the collection.</typeparam>
        /// <typeparam name="TKey">The type of the key to group by.</typeparam>
        /// <param name="source">The collection to group.</param>
        /// <param name="keySelector">The key selector to group the collection.</param>
        /// <returns>A grouped collection.</returns>
        public static IEnumerable<IGrouping<TKey, TSource>> GroupBy<TSource, TKey>(IEnumerable<TSource> source, Func<TSource, TKey> keySelector)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (keySelector == null) throw new ArgumentNullException(nameof(keySelector));

            return source.GroupBy(keySelector);
        }

        /// <summary>
        /// Finds the maximum element in a collection based on a key selector.
        /// </summary>
        /// <typeparam name="TSource">The type of the elements in the collection.</typeparam>
        /// <typeparam name="TKey">The type of the key to find the maximum by.</typeparam>
        /// <param name="source">The collection to find the maximum in.</param>
        /// <param name="keySelector">The key selector to find the maximum by.</param>
        /// <returns>The maximum element in the collection.</returns>
        public static TSource MaxBy<TSource, TKey>(IEnumerable<TSource> source, Func<TSource, TKey> keySelector) where TKey : IComparable<TKey>
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (keySelector == null) throw new ArgumentNullException(nameof(keySelector));

            return source.Aggregate((max, current) => keySelector(current).CompareTo(keySelector(max)) > 0 ? current : max);
        }

        /// <summary>
        /// Finds the minimum element in a collection based on a key selector.
        /// </summary>
        /// <typeparam name="TSource">The type of the elements in the collection.</typeparam>
        /// <typeparam name="TKey">The type of the key to find the minimum by.</typeparam>
        /// <param name="source">The collection to find the minimum in.</param>
        /// <param name="keySelector">The key selector to find the minimum by.</param>
        /// <returns>The minimum element in the collection.</returns>
        public static TSource MinBy<TSource, TKey>(IEnumerable<TSource> source, Func<TSource, TKey> keySelector) where TKey : IComparable<TKey>
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (keySelector == null) throw new ArgumentNullException(nameof(keySelector));

            return source.Aggregate((min, current) => keySelector(current).CompareTo(keySelector(min)) < 0 ? current : min);
        }
    }
}
