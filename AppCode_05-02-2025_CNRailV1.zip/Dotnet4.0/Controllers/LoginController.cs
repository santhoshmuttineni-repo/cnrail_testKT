using System;
using System.Web.Mvc;
using Dotnet4._0.Services;

namespace Dotnet4._0.Controllers
{
    public class LoginController : Controller
    {
        private readonly LoginService _loginService;
        private readonly RememberMeService _rememberMeService;

        public LoginController()
        {
            _loginService = new LoginService();
            _rememberMeService = new RememberMeService();
        }

        [HttpGet]
        public ActionResult Index()
        {
            return View("Login");
        }

        [HttpPost]
        public ActionResult Login(string username, string password, bool rememberMe)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ViewBag.ErrorMessage = "Username and Password are required.";
                return View("Login");
            }

            bool isValidUser = _loginService.ValidateUserCredentials(username, password);
            _loginService.LogLoginAttempt(username, isValidUser);

            if (isValidUser)
            {
                if (rememberMe)
                {
                    string encryptedPassword = EncryptPassword(password);
                    _rememberMeService.StoreCredentials(username, encryptedPassword);
                }
                Session["Username"] = username;
                return RedirectToAction("Dashboard", "Home");
            }
            else
            {
                ViewBag.ErrorMessage = "Invalid Username or Password.";
                return View("Login");
            }
        }

        [HttpPost]
        public ActionResult Logout()
        {
            string username = Session["Username"] as string;
            if (!string.IsNullOrEmpty(username))
            {
                _rememberMeService.ClearCredentials(username);
                Session.Clear();
            }
            return RedirectToAction("Index");
        }

        private string EncryptPassword(string password)
        {
            // Implement encryption logic here
            return Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(password));
        }
    }
}
