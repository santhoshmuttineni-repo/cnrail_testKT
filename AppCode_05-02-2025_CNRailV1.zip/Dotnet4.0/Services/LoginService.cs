using System;
using Dotnet4.0.Repositories;
using Dotnet4.0.Helpers;

namespace Dotnet4.0.Services
{
    public class LoginService
    {
        private readonly LoginRepository _loginRepository;
        private readonly ValidationHelper _validationHelper;
        private readonly LoggingHelper _loggingHelper;

        public LoginService()
        {
            _loginRepository = new LoginRepository();
            _validationHelper = new ValidationHelper();
            _loggingHelper = new LoggingHelper();
        }

        public bool ValidateUserCredentials(string username, string password)
        {
            if (!_validationHelper.ValidateUsername(username) || !_validationHelper.ValidatePassword(password))
            {
                return false;
            }

            bool isValid = _loginRepository.ValidateUserCredentials(username, password);
            LogLoginAttempt(username, isValid);
            return isValid;
        }

        public void LogLoginAttempt(string username, bool success)
        {
            string action = success ? "Login successful" : "Login failed";
            _loggingHelper.LogAction(action, $"Username: {username}");
        }

        public void HandleRememberMe(string username, bool rememberMe)
        {
            _loginRepository.UpdateRememberMe(username, rememberMe);
        }
    }
}
