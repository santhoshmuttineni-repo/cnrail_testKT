using System;
using Dotnet4.0.Helpers;

namespace Dotnet4.0.Services
{
    public class RememberMeService
    {
        private readonly EncryptionHelper _encryptionHelper;
        private readonly CookieHelper _cookieHelper;

        public RememberMeService()
        {
            _encryptionHelper = new EncryptionHelper();
            _cookieHelper = new CookieHelper();
        }

        public void StoreCredentials(string username, string password)
        {
            string encryptedPassword = _encryptionHelper.Encrypt(password);
            DateTime expiry = DateTime.Now.AddDays(30); // Set cookie to expire in 30 days
            _cookieHelper.SetCookie(username, encryptedPassword, expiry);
        }

        public string RetrieveCredentials(string username)
        {
            string encryptedPassword = _cookieHelper.GetCookie(username);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                return null;
            }
            return _encryptionHelper.Decrypt(encryptedPassword);
        }

        public void ClearCredentials(string username)
        {
            _cookieHelper.DeleteCookie(username);
        }
    }
}
