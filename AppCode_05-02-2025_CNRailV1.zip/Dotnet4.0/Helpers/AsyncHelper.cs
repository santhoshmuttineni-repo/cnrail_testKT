using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dotnet4._0.Helpers
{
    public static class AsyncHelper
    {
        public static async Task RunAsync(Func<Task> asyncAction)
        {
            await Task.Run(asyncAction);
        }

        public static async Task<T> RunAsync<T>(Func<Task<T>> asyncFunc)
        {
            return await Task.Run(asyncFunc);
        }

        public static async Task RunParallelAsync(IEnumerable<Func<Task>> asyncActions)
        {
            var tasks = asyncActions.Select(action => Task.Run(action));
            await Task.WhenAll(tasks);
        }

        public static async Task<IEnumerable<T>> RunParallelAsync<T>(IEnumerable<Func<Task<T>>> asyncFuncs)
        {
            var tasks = asyncFuncs.Select(func => Task.Run(func));
            return await Task.WhenAll(tasks);
        }

        public static async Task RunWithTimeoutAsync(Func<Task> asyncAction, TimeSpan timeout)
        {
            var task = Task.Run(asyncAction);
            if (await Task.WhenAny(task, Task.Delay(timeout)) == task)
            {
                await task;
            }
            else
            {
                throw new TimeoutException("The operation has timed out.");
            }
        }

        public static async Task<T> RunWithTimeoutAsync<T>(Func<Task<T>> asyncFunc, TimeSpan timeout)
        {
            var task = Task.Run(asyncFunc);
            if (await Task.WhenAny(task, Task.Delay(timeout)) == task)
            {
                return await task;
            }
            else
            {
                throw new TimeoutException("The operation has timed out.");
            }
        }

        public static async Task RetryOnExceptionAsync(Func<Task> asyncAction, int maxRetries, TimeSpan delay)
        {
            int retryCount = 0;
            while (true)
            {
                try
                {
                    await Task.Run(asyncAction);
                    break;
                }
                catch
                {
                    if (++retryCount == maxRetries)
                        throw;
                    await Task.Delay(delay);
                }
            }
        }

        public static async Task<T> RetryOnExceptionAsync<T>(Func<Task<T>> asyncFunc, int maxRetries, TimeSpan delay)
        {
            int retryCount = 0;
            while (true)
            {
                try
                {
                    return await Task.Run(asyncFunc);
                }
                catch
                {
                    if (++retryCount == maxRetries)
                        throw;
                    await Task.Delay(delay);
                }
            }
        }
    }
}
