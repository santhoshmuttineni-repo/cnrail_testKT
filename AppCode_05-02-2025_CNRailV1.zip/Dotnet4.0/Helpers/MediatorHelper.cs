using System;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Security;

namespace Dotnet4._0.Helpers
{
    public static class MediatorHelper
    {
        // Method to handle user login
        public static bool HandleUserLogin(string username, string password, bool rememberMe)
        {
            // Validate user credentials
            if (ValidateUserCredentials(username, password))
            {
                // Set authentication cookie
                SetAuthCookie(username, rememberMe);
                return true;
            }
            return false;
        }

        // Method to validate user credentials
        private static bool ValidateUserCredentials(string username, string password)
        {
            // Fetch user details from the database (pseudo-code)
            var user = GetUserFromDatabase(username);

            if (user != null)
            {
                // Compare the provided password with the stored password
                return VerifyPassword(password, user.Password);
            }
            return false;
        }

        // Method to fetch user details from the database (pseudo-code)
        private static User GetUserFromDatabase(string username)
        {
            // This is a placeholder for actual database interaction
            // Replace with actual database call
            return new User
            {
                Username = username,
                Password = "hashed_password_from_db",
                RememberMe = false
            };
        }

        // Method to verify the password
        private static bool VerifyPassword(string providedPassword, string storedPassword)
        {
            // Hash the provided password and compare with the stored password
            var hashedPassword = HashPassword(providedPassword);
            return hashedPassword == storedPassword;
        }

        // Method to hash the password
        private static string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(password);
                var hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }

        // Method to set authentication cookie
        private static void SetAuthCookie(string username, bool rememberMe)
        {
            FormsAuthentication.SetAuthCookie(username, rememberMe);
        }

        // Method to handle "Remember Me" functionality
        public static void HandleRememberMe(HttpContext context, string username, bool rememberMe)
        {
            if (rememberMe)
            {
                // Create a persistent cookie
                var authTicket = new FormsAuthenticationTicket(
                    1,
                    username,
                    DateTime.Now,
                    DateTime.Now.AddDays(30),
                    true,
                    string.Empty
                );

                string encryptedTicket = FormsAuthentication.Encrypt(authTicket);
                var authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket)
                {
                    Expires = authTicket.Expiration,
                    HttpOnly = true
                };

                context.Response.Cookies.Add(authCookie);
            }
        }

        // Method to clear authentication cookie
        public static void ClearAuthCookie(HttpContext context)
        {
            FormsAuthentication.SignOut();
            var authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, string.Empty)
            {
                Expires = DateTime.Now.AddYears(-1),
                HttpOnly = true
            };
            context.Response.Cookies.Add(authCookie);
        }
    }

    // Placeholder class for User
    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public bool RememberMe { get; set; }
    }
}
