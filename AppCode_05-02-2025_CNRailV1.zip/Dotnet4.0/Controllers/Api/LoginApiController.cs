using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Dotnet4._0.Services;

namespace Dotnet4._0.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    public class LoginApiController : ControllerBase
    {
        private readonly ILogger<LoginApiController> _logger;
        private readonly IConfiguration _configuration;
        private readonly LoginService _loginService;

        public LoginApiController(ILogger<LoginApiController> logger, IConfiguration configuration, LoginService loginService)
        {
            _logger = logger;
            _configuration = configuration;
            _loginService = loginService;
        }

        [HttpPost]
        public IActionResult Login([FromBody] LoginRequest loginRequest)
        {
            if (loginRequest == null || string.IsNullOrEmpty(loginRequest.Username) || string.IsNullOrEmpty(loginRequest.Password))
            {
                return BadRequest("Username and password are required.");
            }

            bool isValidUser = _loginService.ValidateUserCredentials(loginRequest.Username, loginRequest.Password);
            _loginService.LogLoginAttempt(loginRequest.Username, isValidUser);

            if (!isValidUser)
            {
                return Unauthorized("Invalid username or password.");
            }

            if (loginRequest.RememberMe)
            {
                _loginService.HandleRememberMe(loginRequest.Username, true);
            }
            else
            {
                _loginService.HandleRememberMe(loginRequest.Username, false);
            }

            return Ok("Login successful.");
        }
    }

    public class LoginRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public bool RememberMe { get; set; }
    }
}
