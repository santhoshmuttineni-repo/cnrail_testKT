using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dotnet4._0.Services;

namespace Dotnet4._0.Helpers
{
    public class ObserverHelper
    {
        private readonly RememberMeService _rememberMeService;

        public ObserverHelper(RememberMeService rememberMeService)
        {
            _rememberMeService = rememberMeService;
        }

        public void ObserveLoginStateChanges(string username, string password, bool rememberMe)
        {
            if (rememberMe)
            {
                _rememberMeService.StoreCredentials(username, password);
            }
            else
            {
                _rememberMeService.ClearCredentials();
            }
        }

        public (string username, string password) RetrieveStoredCredentials()
        {
            return _rememberMeService.RetrieveCredentials();
        }

        public bool ValidateLoginForm(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                return false;
            }

            // Additional validation logic can be added here
            return true;
        }
    }
}
