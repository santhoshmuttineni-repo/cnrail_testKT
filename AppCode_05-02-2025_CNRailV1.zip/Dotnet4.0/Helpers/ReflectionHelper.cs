using System;
using System.Reflection;

namespace Dotnet4._0.Helpers
{
    public static class ReflectionHelper
    {
        /// <summary>
        /// Gets the value of a property from an object using reflection.
        /// </summary>
        /// <param name="obj">The object from which to get the property value.</param>
        /// <param name="propertyName">The name of the property.</param>
        /// <returns>The value of the property.</returns>
        public static object GetPropertyValue(object obj, string propertyName)
        {
            if (obj == null) throw new ArgumentNullException(nameof(obj));
            if (string.IsNullOrEmpty(propertyName)) throw new ArgumentNullException(nameof(propertyName));

            PropertyInfo property = obj.GetType().GetProperty(propertyName, BindingFlags.Public | BindingFlags.Instance);
            if (property == null) throw new ArgumentException($"Property '{propertyName}' not found on type '{obj.GetType().FullName}'.");

            return property.GetValue(obj, null);
        }

        /// <summary>
        /// Sets the value of a property on an object using reflection.
        /// </summary>
        /// <param name="obj">The object on which to set the property value.</param>
        /// <param name="propertyName">The name of the property.</param>
        /// <param name="value">The value to set.</param>
        public static void SetPropertyValue(object obj, string propertyName, object value)
        {
            if (obj == null) throw new ArgumentNullException(nameof(obj));
            if (string.IsNullOrEmpty(propertyName)) throw new ArgumentNullException(nameof(propertyName));

            PropertyInfo property = obj.GetType().GetProperty(propertyName, BindingFlags.Public | BindingFlags.Instance);
            if (property == null) throw new ArgumentException($"Property '{propertyName}' not found on type '{obj.GetType().FullName}'.");

            property.SetValue(obj, value, null);
        }

        /// <summary>
        /// Invokes a method on an object using reflection.
        /// </summary>
        /// <param name="obj">The object on which to invoke the method.</param>
        /// <param name="methodName">The name of the method.</param>
        /// <param name="parameters">The parameters to pass to the method.</param>
        /// <returns>The result of the method invocation.</returns>
        public static object InvokeMethod(object obj, string methodName, params object[] parameters)
        {
            if (obj == null) throw new ArgumentNullException(nameof(obj));
            if (string.IsNullOrEmpty(methodName)) throw new ArgumentNullException(nameof(methodName));

            MethodInfo method = obj.GetType().GetMethod(methodName, BindingFlags.Public | BindingFlags.Instance);
            if (method == null) throw new ArgumentException($"Method '{methodName}' not found on type '{obj.GetType().FullName}'.");

            return method.Invoke(obj, parameters);
        }
    }
}
