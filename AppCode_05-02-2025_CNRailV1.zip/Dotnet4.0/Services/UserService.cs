using System;
using Dotnet4.0.Repositories;

namespace Dotnet4.0.Services
{
    public class UserService
    {
        private readonly UserRepository _userRepository;

        public UserService(UserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public bool ValidateUserCredentials(string username, string password)
        {
            // Validate the user's credentials against the stored data
            return _userRepository.ValidateUserCredentials(username, password);
        }

        public void HandleRememberMe(string username, bool rememberMe)
        {
            // Handle the 'Remember Me' functionality
            _userRepository.UpdateRememberMe(username, rememberMe);
        }
    }
}
