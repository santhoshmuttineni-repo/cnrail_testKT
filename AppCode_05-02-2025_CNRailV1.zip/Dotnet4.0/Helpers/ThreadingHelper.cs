using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Dotnet4.0.Helpers
{
    public static class ThreadingHelper
    {
        // Method to run a task in a separate thread
        public static void RunInNewThread(Action action)
        {
            Thread thread = new Thread(new ThreadStart(action));
            thread.Start();
        }

        // Method to run a task with a timeout
        public static bool RunWithTimeout(Action action, int timeoutMilliseconds)
        {
            Task task = Task.Run(action);
            return task.Wait(timeoutMilliseconds);
        }

        // Method to run multiple tasks in parallel
        public static void RunInParallel(IEnumerable<Action> actions)
        {
            Parallel.ForEach(actions, action => action());
        }

        // Method to run a task and return a result
        public static TResult RunWithResult<TResult>(Func<TResult> func)
        {
            Task<TResult> task = Task.Run(func);
            task.Wait();
            return task.Result;
        }

        // Method to run a task with cancellation support
        public static void RunWithCancellation(Action action, CancellationToken cancellationToken)
        {
            Task task = Task.Run(action, cancellationToken);
            try
            {
                task.Wait(cancellationToken);
            }
            catch (OperationCanceledException)
            {
                // Handle the cancellation
            }
        }

        // Method to run a task periodically
        public static void RunPeriodically(Action action, TimeSpan interval, CancellationToken cancellationToken)
        {
            Task.Run(async () =>
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    action();
                    await Task.Delay(interval, cancellationToken);
                }
            }, cancellationToken);
        }
    }
}
