using System;
using System.Security.Cryptography;
using System.Text;
using System.IO;

namespace Dotnet4._0.Helpers
{
    public static class CompositeHelper
    {
        private static readonly string EncryptionKey = "your-encryption-key"; // Replace with a secure key

        public static bool ValidateLogin(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                return false;
            }

            // Add additional validation logic if needed
            return true;
        }

        public static void LogLoginAttempt(string username, bool success)
        {
            // Implement logging logic here
            // Example: Log to a file or a database
            string logMessage = $"{DateTime.Now}: Login attempt for user '{username}' was {(success ? "successful" : "unsuccessful")}.";
            File.AppendAllText("login_attempts.log", logMessage + Environment.NewLine);
        }

        public static void RememberMe(string username, string password)
        {
            string encryptedCredentials = EncryptCredentials(username, password);
            // Store the encrypted credentials securely
            // Example: Save to a file or a secure storage
            File.WriteAllText("remember_me.txt", encryptedCredentials);
        }

        public static (string username, string password) RetrieveRememberedCredentials()
        {
            if (File.Exists("remember_me.txt"))
            {
                string encryptedCredentials = File.ReadAllText("remember_me.txt");
                return DecryptCredentials(encryptedCredentials);
            }

            return (null, null);
        }

        private static string EncryptCredentials(string username, string password)
        {
            string credentials = $"{username}:{password}";
            byte[] clearBytes = Encoding.Unicode.GetBytes(credentials);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    credentials = Convert.ToBase64String(ms.ToArray());
                }
            }
            return credentials;
        }

        private static (string username, string password) DecryptCredentials(string encryptedCredentials)
        {
            encryptedCredentials = encryptedCredentials.Replace(" ", "+");
            byte[] cipherBytes = Convert.FromBase64String(encryptedCredentials);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    encryptedCredentials = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            string[] credentials = encryptedCredentials.Split(':');
            return (credentials[0], credentials[1]);
        }
    }
}
