using System;
using System.Web;
using System.Web.Security;
using System.Security.Cryptography;
using System.Text;

namespace Dotnet4._0.Helpers
{
    public static class VisitorHelper
    {
        // Method to manage user sessions
        public static void ManageUserSession(string username, bool rememberMe)
        {
            if (rememberMe)
            {
                CreateRememberMeCookie(username);
            }
            else
            {
                HttpContext.Current.Session["username"] = username;
            }
        }

        // Method to handle 'Remember Me' functionality
        private static void CreateRememberMeCookie(string username)
        {
            var ticket = new FormsAuthenticationTicket(
                1, 
                username, 
                DateTime.Now, 
                DateTime.Now.AddDays(30), 
                true, 
                string.Empty, 
                FormsAuthentication.FormsCookiePath);

            string encryptedTicket = FormsAuthentication.Encrypt(ticket);
            var cookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket)
            {
                HttpOnly = true,
                Secure = FormsAuthentication.RequireSSL,
                Expires = DateTime.Now.AddDays(30)
            };

            HttpContext.Current.Response.Cookies.Add(cookie);
        }

        // Method to securely store login credentials
        public static void StoreLoginCredentials(string username, string password)
        {
            string encryptedPassword = EncryptPassword(password);
            // Store the encrypted password in the database
            // This is a placeholder for actual database interaction code
            // Database.StoreUserCredentials(username, encryptedPassword);
        }

        // Method to encrypt the password
        private static string EncryptPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                var builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        // Method to validate user credentials
        public static bool ValidateUserCredentials(string username, string password)
        {
            string encryptedPassword = EncryptPassword(password);
            // Validate the encrypted password with the stored password in the database
            // This is a placeholder for actual database interaction code
            // return Database.ValidateUserCredentials(username, encryptedPassword);
            return true; // Placeholder return value
        }

        // Method to clear 'Remember Me' cookie
        public static void ClearRememberMeCookie()
        {
            var cookie = new HttpCookie(FormsAuthentication.FormsCookieName)
            {
                Expires = DateTime.Now.AddDays(-1),
                HttpOnly = true,
                Secure = FormsAuthentication.RequireSSL
            };

            HttpContext.Current.Response.Cookies.Add(cookie);
        }
    }
}
