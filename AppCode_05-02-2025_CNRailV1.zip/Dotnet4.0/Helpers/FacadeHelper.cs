using System;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Security;

namespace Dotnet4.0.Helpers
{
    public class FacadeHelper
    {
        private readonly IUserService _userService;
        private readonly IRememberMeService _rememberMeService;

        public FacadeHelper(IUserService userService, IRememberMeService rememberMeService)
        {
            _userService = userService;
            _rememberMeService = rememberMeService;
        }

        public bool Login(string username, string password, bool rememberMe)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                throw new ArgumentException("Username and password are required.");
            }

            var user = _userService.GetUserByUsername(username);
            if (user == null || !VerifyPassword(password, user.Password))
            {
                return false;
            }

            if (rememberMe)
            {
                var encryptedCredentials = EncryptCredentials(username, password);
                _rememberMeService.StoreCredentials(encryptedCredentials);
            }

            FormsAuthentication.SetAuthCookie(username, rememberMe);
            return true;
        }

        public void Logout()
        {
            FormsAuthentication.SignOut();
            _rememberMeService.ClearCredentials();
        }

        private bool VerifyPassword(string inputPassword, string storedPassword)
        {
            // Assuming storedPassword is hashed
            var hashedInputPassword = HashPassword(inputPassword);
            return hashedInputPassword == storedPassword;
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(password);
                var hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }

        private string EncryptCredentials(string username, string password)
        {
            var credentials = $"{username}:{password}";
            var bytes = Encoding.UTF8.GetBytes(credentials);
            using (var aes = Aes.Create())
            {
                aes.GenerateKey();
                aes.GenerateIV();
                var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
                var encryptedBytes = encryptor.TransformFinalBlock(bytes, 0, bytes.Length);
                return Convert.ToBase64String(encryptedBytes);
            }
        }
    }

    public interface IUserService
    {
        User GetUserByUsername(string username);
    }

    public interface IRememberMeService
    {
        void StoreCredentials(string encryptedCredentials);
        void ClearCredentials();
    }

    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
