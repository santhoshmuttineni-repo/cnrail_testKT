using System;
using System.Globalization;

namespace Dotnet4._0.Helpers
{
    public static class NumberHelper
    {
        /// <summary>
        /// Parses a string to an integer. Returns null if parsing fails.
        /// </summary>
        /// <param name="input">The string to parse.</param>
        /// <returns>The parsed integer or null if parsing fails.</returns>
        public static int? ParseInt(string input)
        {
            if (int.TryParse(input, out int result))
            {
                return result;
            }
            return null;
        }

        /// <summary>
        /// Parses a string to a double. Returns null if parsing fails.
        /// </summary>
        /// <param name="input">The string to parse.</param>
        /// <returns>The parsed double or null if parsing fails.</returns>
        public static double? ParseDouble(string input)
        {
            if (double.TryParse(input, NumberStyles.Any, CultureInfo.InvariantCulture, out double result))
            {
                return result;
            }
            return null;
        }

        /// <summary>
        /// Formats an integer to a string with the specified number of digits.
        /// </summary>
        /// <param name="number">The number to format.</param>
        /// <param name="digits">The number of digits in the formatted string.</param>
        /// <returns>The formatted string.</returns>
        public static string FormatInt(int number, int digits)
        {
            return number.ToString($"D{digits}");
        }

        /// <summary>
        /// Formats a double to a string with the specified number of decimal places.
        /// </summary>
        /// <param name="number">The number to format.</param>
        /// <param name="decimalPlaces">The number of decimal places in the formatted string.</param>
        /// <returns>The formatted string.</returns>
        public static string FormatDouble(double number, int decimalPlaces)
        {
            return number.ToString($"F{decimalPlaces}", CultureInfo.InvariantCulture);
        }

        /// <summary>
        /// Validates if a string is a valid integer.
        /// </summary>
        /// <param name="input">The string to validate.</param>
        /// <returns>True if the string is a valid integer, otherwise false.</returns>
        public static bool IsValidInt(string input)
        {
            return int.TryParse(input, out _);
        }

        /// <summary>
        /// Validates if a string is a valid double.
        /// </summary>
        /// <param name="input">The string to validate.</param>
        /// <returns>True if the string is a valid double, otherwise false.</returns>
        public static bool IsValidDouble(string input)
        {
            return double.TryParse(input, NumberStyles.Any, CultureInfo.InvariantCulture, out _);
        }
    }
}
