using System;
using System.Collections.Generic;
using System.Globalization;
using System.Resources;
using System.Threading;

namespace Dotnet4._0.Helpers
{
    public static class LocalizationHelper
    {
        private static ResourceManager resourceManager;
        private static CultureInfo currentCulture;

        static LocalizationHelper()
        {
            resourceManager = new ResourceManager("Dotnet4._0.Resources.Localization", typeof(LocalizationHelper).Assembly);
            currentCulture = CultureInfo.CurrentCulture;
        }

        public static void SetCulture(string cultureName)
        {
            try
            {
                currentCulture = new CultureInfo(cultureName);
                Thread.CurrentThread.CurrentCulture = currentCulture;
                Thread.CurrentThread.CurrentUICulture = currentCulture;
            }
            catch (CultureNotFoundException)
            {
                // Handle exception for invalid culture name
            }
        }

        public static string GetLocalizedString(string key)
        {
            return resourceManager.GetString(key, currentCulture);
        }

        public static string GetLocalizedString(string key, string cultureName)
        {
            try
            {
                var culture = new CultureInfo(cultureName);
                return resourceManager.GetString(key, culture);
            }
            catch (CultureNotFoundException)
            {
                // Handle exception for invalid culture name
                return null;
            }
        }

        public static Dictionary<string, string> GetAllLocalizedStrings()
        {
            var resourceSet = resourceManager.GetResourceSet(currentCulture, true, true);
            var localizedStrings = new Dictionary<string, string>();

            foreach (System.Collections.DictionaryEntry entry in resourceSet)
            {
                localizedStrings.Add(entry.Key.ToString(), entry.Value.ToString());
            }

            return localizedStrings;
        }

        public static Dictionary<string, string> GetAllLocalizedStrings(string cultureName)
        {
            try
            {
                var culture = new CultureInfo(cultureName);
                var resourceSet = resourceManager.GetResourceSet(culture, true, true);
                var localizedStrings = new Dictionary<string, string>();

                foreach (System.Collections.DictionaryEntry entry in resourceSet)
                {
                    localizedStrings.Add(entry.Key.ToString(), entry.Value.ToString());
                }

                return localizedStrings;
            }
            catch (CultureNotFoundException)
            {
                // Handle exception for invalid culture name
                return null;
            }
        }
    }
}
