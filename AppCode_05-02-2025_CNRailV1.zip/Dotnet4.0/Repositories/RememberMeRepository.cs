using System;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.Linq;
using System.Data.Entity;

namespace Dotnet4._0.Repositories
{
    public class RememberMeRepository
    {
        private readonly MyDbContext _context;
        private readonly string _encryptionKey = "your-encryption-key"; // Replace with your actual encryption key

        public RememberMeRepository(MyDbContext context)
        {
            _context = context;
        }

        public void SaveCredentials(string username, string password)
        {
            var encryptedUsername = Encrypt(username);
            var encryptedPassword = Encrypt(password);

            var user = _context.Users.SingleOrDefault(u => u.Username == encryptedUsername);
            if (user != null)
            {
                user.Password = encryptedPassword;
                user.RememberMe = true;
            }
            else
            {
                _context.Users.Add(new User
                {
                    Username = encryptedUsername,
                    Password = encryptedPassword,
                    RememberMe = true
                });
            }

            _context.SaveChanges();
        }

        public (string Username, string Password) RetrieveCredentials()
        {
            var user = _context.Users.SingleOrDefault(u => u.RememberMe);
            if (user != null)
            {
                var decryptedUsername = Decrypt(user.Username);
                var decryptedPassword = Decrypt(user.Password);
                return (decryptedUsername, decryptedPassword);
            }

            return (null, null);
        }

        public void ClearCredentials()
        {
            var users = _context.Users.Where(u => u.RememberMe).ToList();
            foreach (var user in users)
            {
                user.RememberMe = false;
            }

            _context.SaveChanges();
        }

        private string Encrypt(string plainText)
        {
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
            using (var aes = Aes.Create())
            {
                var key = new Rfc2898DeriveBytes(_encryptionKey, new byte[16]);
                aes.Key = key.GetBytes(32);
                aes.IV = key.GetBytes(16);

                using (var encryptor = aes.CreateEncryptor(aes.Key, aes.IV))
                {
                    using (var ms = new MemoryStream())
                    {
                        using (var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                        {
                            cs.Write(plainBytes, 0, plainBytes.Length);
                            cs.Close();
                        }
                        return Convert.ToBase64String(ms.ToArray());
                    }
                }
            }
        }

        private string Decrypt(string encryptedText)
        {
            byte[] cipherBytes = Convert.FromBase64String(encryptedText);
            using (var aes = Aes.Create())
            {
                var key = new Rfc2898DeriveBytes(_encryptionKey, new byte[16]);
                aes.Key = key.GetBytes(32);
                aes.IV = key.GetBytes(16);

                using (var decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
                {
                    using (var ms = new MemoryStream(cipherBytes))
                    {
                        using (var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                        {
                            using (var reader = new StreamReader(cs))
                            {
                                return reader.ReadToEnd();
                            }
                        }
                    }
                }
            }
        }
    }

    public class MyDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }
    }

    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public bool RememberMe { get; set; }
    }
}
