using System;
using System.Security.Cryptography;
using System.Text;

namespace Dotnet4._0.Helpers
{
    public static class StrategyHelper
    {
        // Method to handle standard login
        public static bool StandardLogin(string username, string password)
        {
            // Fetch user details from the database
            var user = GetUserFromDatabase(username);
            if (user == null)
            {
                return false;
            }

            // Verify the password
            return VerifyPassword(password, user.Password);
        }

        // Method to handle "Remember Me" functionality
        public static bool RememberMeLogin(string username, string encryptedPassword)
        {
            // Fetch user details from the database
            var user = GetUserFromDatabase(username);
            if (user == null)
            {
                return false;
            }

            // Decrypt the stored password
            var decryptedPassword = DecryptPassword(encryptedPassword);

            // Verify the password
            return VerifyPassword(decryptedPassword, user.Password);
        }

        // Method to encrypt the password
        public static string EncryptPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(password);
                var hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }

        // Method to decrypt the password
        public static string DecryptPassword(string encryptedPassword)
        {
            // Assuming the encryption is reversible, which is not the case with SHA256
            // This is a placeholder for actual decryption logic if a reversible encryption algorithm is used
            return encryptedPassword;
        }

        // Method to verify the password
        private static bool VerifyPassword(string inputPassword, string storedPassword)
        {
            var encryptedInputPassword = EncryptPassword(inputPassword);
            return encryptedInputPassword == storedPassword;
        }

        // Method to fetch user details from the database
        private static User GetUserFromDatabase(string username)
        {
            // Placeholder for actual database fetching logic
            // This should be replaced with actual database interaction code
            return new User
            {
                Username = username,
                Password = "encryptedPasswordFromDb",
                RememberMe = true
            };
        }
    }

    // Placeholder for User class
    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public bool RememberMe { get; set; }
    }
}
