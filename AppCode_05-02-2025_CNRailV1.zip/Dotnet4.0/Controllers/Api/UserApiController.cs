using System;
using System.Web.Http;
using Dotnet4._0.Services;

namespace Dotnet4._0.Controllers.Api
{
    public class UserApiController : ApiController
    {
        private readonly UserService _userService;

        public UserApiController()
        {
            _userService = new UserService();
        }

        [HttpPost]
        [Route("api/user/login")]
        public IHttpActionResult Login(string username, string password, bool rememberMe)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                return BadRequest("Username and password are required.");
            }

            var isValidUser = _userService.ValidateUserCredentials(username, password);
            if (!isValidUser)
            {
                return Unauthorized();
            }

            _userService.HandleRememberMe(username, rememberMe);

            return Ok("Login successful.");
        }
    }
}
