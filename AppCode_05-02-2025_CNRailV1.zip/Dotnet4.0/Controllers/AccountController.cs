using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Dotnet4._0.Services;

namespace Dotnet4._0.Controllers
{
    public class AccountController : Controller
    {
        private readonly IAccountService _accountService;
        private readonly ILogger<AccountController> _logger;
        private readonly IConfiguration _configuration;

        public AccountController(IAccountService accountService, ILogger<AccountController> logger, IConfiguration configuration)
        {
            _accountService = accountService;
            _logger = logger;
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password, bool rememberMe)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ViewBag.ErrorMessage = "Username and Password are required.";
                return View();
            }

            var result = _accountService.LoginUser(username, password, rememberMe);
            if (result)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.ErrorMessage = "Invalid login attempt.";
                return View();
            }
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ViewBag.ErrorMessage = "Username and Password are required.";
                return View();
            }

            var result = _accountService.RegisterUser(username, password);
            if (result)
            {
                return RedirectToAction("Login");
            }
            else
            {
                ViewBag.ErrorMessage = "Registration failed.";
                return View();
            }
        }

        [HttpGet]
        public IActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ForgotPassword(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                ViewBag.ErrorMessage = "Username is required.";
                return View();
            }

            var result = _accountService.ForgotPassword(username);
            if (result)
            {
                ViewBag.Message = "Password reset instructions have been sent to your email.";
                return View();
            }
            else
            {
                ViewBag.ErrorMessage = "Failed to initiate password reset.";
                return View();
            }
        }

        [HttpGet]
        public IActionResult ResetPassword()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ResetPassword(string username, string newPassword)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(newPassword))
            {
                ViewBag.ErrorMessage = "Username and New Password are required.";
                return View();
            }

            var result = _accountService.ResetPassword(username, newPassword);
            if (result)
            {
                ViewBag.Message = "Password has been reset successfully.";
                return RedirectToAction("Login");
            }
            else
            {
                ViewBag.ErrorMessage = "Failed to reset password.";
                return View();
            }
        }
    }
}
