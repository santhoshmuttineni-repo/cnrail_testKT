using System;
using System.Collections.Generic;
using System.Linq;

namespace Dotnet4._0.Helpers
{
    public static class ListHelper
    {
        // Method to sort a list of integers in ascending order
        public static List<int> SortListAscending(List<int> list)
        {
            if (list == null)
                throw new ArgumentNullException(nameof(list));

            return list.OrderBy(x => x).ToList();
        }

        // Method to sort a list of integers in descending order
        public static List<int> SortListDescending(List<int> list)
        {
            if (list == null)
                throw new ArgumentNullException(nameof(list));

            return list.OrderByDescending(x => x).ToList();
        }

        // Method to filter a list of integers based on a predicate
        public static List<int> FilterList(List<int> list, Func<int, bool> predicate)
        {
            if (list == null)
                throw new ArgumentNullException(nameof(list));
            if (predicate == null)
                throw new ArgumentNullException(nameof(predicate));

            return list.Where(predicate).ToList();
        }

        // Method to find the maximum value in a list of integers
        public static int FindMaxValue(List<int> list)
        {
            if (list == null)
                throw new ArgumentNullException(nameof(list));
            if (list.Count == 0)
                throw new InvalidOperationException("List is empty");

            return list.Max();
        }

        // Method to find the minimum value in a list of integers
        public static int FindMinValue(List<int> list)
        {
            if (list == null)
                throw new ArgumentNullException(nameof(list));
            if (list.Count == 0)
                throw new InvalidOperationException("List is empty");

            return list.Min();
        }

        // Method to calculate the sum of all integers in a list
        public static int CalculateSum(List<int> list)
        {
            if (list == null)
                throw new ArgumentNullException(nameof(list));

            return list.Sum();
        }

        // Method to calculate the average of all integers in a list
        public static double CalculateAverage(List<int> list)
        {
            if (list == null)
                throw new ArgumentNullException(nameof(list));
            if (list.Count == 0)
                throw new InvalidOperationException("List is empty");

            return list.Average();
        }

        // Method to check if a list contains a specific value
        public static bool ContainsValue(List<int> list, int value)
        {
            if (list == null)
                throw new ArgumentNullException(nameof(list));

            return list.Contains(value);
        }

        // Method to remove duplicates from a list of integers
        public static List<int> RemoveDuplicates(List<int> list)
        {
            if (list == null)
                throw new ArgumentNullException(nameof(list));

            return list.Distinct().ToList();
        }

        // Method to reverse a list of integers
        public static List<int> ReverseList(List<int> list)
        {
            if (list == null)
                throw new ArgumentNullException(nameof(list));

            list.Reverse();
            return list;
        }
    }
}
