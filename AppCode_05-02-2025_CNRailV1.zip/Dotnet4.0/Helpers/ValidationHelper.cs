using System;
using System.Text.RegularExpressions;

namespace Dotnet4.0.Helpers
{
    public static class ValidationHelper
    {
        /// <summary>
        /// Validates the username field for the login form.
        /// </summary>
        /// <param name="username">The username to validate.</param>
        /// <returns>True if the username is valid, otherwise false.</returns>
        public static bool ValidateUsername(string username)
        {
            if (string.IsNullOrWhiteSpace(username))
            {
                return false;
            }

            // Additional validation logic can be added here (e.g., regex for allowed characters)
            return true;
        }

        /// <summary>
        /// Validates the password field for the login form.
        /// </summary>
        /// <param name="password">The password to validate.</param>
        /// <returns>True if the password is valid, otherwise false.</returns>
        public static bool ValidatePassword(string password)
        {
            if (string.IsNullOrWhiteSpace(password))
            {
                return false;
            }

            // Additional validation logic can be added here (e.g., minimum length, complexity requirements)
            return true;
        }
    }
}
