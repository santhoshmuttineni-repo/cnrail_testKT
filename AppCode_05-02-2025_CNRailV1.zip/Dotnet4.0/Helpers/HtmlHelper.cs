using System;
using System.Text;
using System.Web.Mvc;
using System.Web.Routing;

namespace Dotnet4._0.Helpers
{
    public static class HtmlHelperExtensions
    {
        public static MvcHtmlString TextBox(this HtmlHelper htmlHelper, string name, object value = null, object htmlAttributes = null)
        {
            var builder = new TagBuilder("input");
            builder.MergeAttribute("type", "text");
            builder.MergeAttribute("name", name);
            builder.MergeAttribute("id", name);
            builder.MergeAttribute("value", value != null ? value.ToString() : string.Empty);
            builder.MergeAttributes(new RouteValueDictionary(htmlAttributes));
            return MvcHtmlString.Create(builder.ToString(TagRenderMode.SelfClosing));
        }

        public static MvcHtmlString PasswordBox(this HtmlHelper htmlHelper, string name, object htmlAttributes = null)
        {
            var builder = new TagBuilder("input");
            builder.MergeAttribute("type", "password");
            builder.MergeAttribute("name", name);
            builder.MergeAttribute("id", name);
            builder.MergeAttributes(new RouteValueDictionary(htmlAttributes));
            return MvcHtmlString.Create(builder.ToString(TagRenderMode.SelfClosing));
        }

        public static MvcHtmlString CheckBox(this HtmlHelper htmlHelper, string name, bool isChecked, object htmlAttributes = null)
        {
            var builder = new TagBuilder("input");
            builder.MergeAttribute("type", "checkbox");
            builder.MergeAttribute("name", name);
            builder.MergeAttribute("id", name);
            if (isChecked)
            {
                builder.MergeAttribute("checked", "checked");
            }
            builder.MergeAttributes(new RouteValueDictionary(htmlAttributes));
            return MvcHtmlString.Create(builder.ToString(TagRenderMode.SelfClosing));
        }

        public static MvcHtmlString ValidationMessage(this HtmlHelper htmlHelper, string name, string message, object htmlAttributes = null)
        {
            var builder = new TagBuilder("span");
            builder.MergeAttribute("data-valmsg-for", name);
            builder.MergeAttribute("data-valmsg-replace", "true");
            builder.SetInnerText(message);
            builder.MergeAttributes(new RouteValueDictionary(htmlAttributes));
            return MvcHtmlString.Create(builder.ToString());
        }

        public static MvcHtmlString BeginForm(this HtmlHelper htmlHelper, string actionName, string controllerName, FormMethod method, object htmlAttributes = null)
        {
            var urlHelper = new UrlHelper(htmlHelper.ViewContext.RequestContext);
            var formTag = new TagBuilder("form");
            formTag.MergeAttribute("action", urlHelper.Action(actionName, controllerName));
            formTag.MergeAttribute("method", method.ToString().ToUpper());
            formTag.MergeAttributes(new RouteValueDictionary(htmlAttributes));
            htmlHelper.ViewContext.Writer.Write(formTag.ToString(TagRenderMode.StartTag));
            return MvcHtmlString.Empty;
        }

        public static MvcHtmlString EndForm(this HtmlHelper htmlHelper)
        {
            return MvcHtmlString.Create("</form>");
        }
    }
}
