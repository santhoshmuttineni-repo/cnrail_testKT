using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Dotnet4._0.Helpers
{
    public class FlyweightHelper
    {
        private static readonly Dictionary<string, UserCredentials> _credentialsCache = new Dictionary<string, UserCredentials>();

        public UserCredentials GetUserCredentials(string username, string password, bool rememberMe)
        {
            string key = GenerateKey(username, password, rememberMe);
            if (!_credentialsCache.ContainsKey(key))
            {
                var encryptedPassword = EncryptPassword(password);
                _credentialsCache[key] = new UserCredentials(username, encryptedPassword, rememberMe);
            }
            return _credentialsCache[key];
        }

        private string GenerateKey(string username, string password, bool rememberMe)
        {
            return $"{username}:{password}:{rememberMe}";
        }

        private string EncryptPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }

    public class UserCredentials
    {
        public string Username { get; }
        public string EncryptedPassword { get; }
        public bool RememberMe { get; }

        public UserCredentials(string username, string encryptedPassword, bool rememberMe)
        {
            Username = username;
            EncryptedPassword = encryptedPassword;
            RememberMe = rememberMe;
        }
    }
}
