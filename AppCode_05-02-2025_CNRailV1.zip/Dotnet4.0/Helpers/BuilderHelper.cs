using System;
using System.Text.RegularExpressions;
using System.Security.Cryptography;
using System.Text;

namespace Dotnet4.0.Helpers
{
    public static class BuilderHelper
    {
        // Method to validate the username
        public static bool ValidateUsername(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                return false;
            }
            // Add more validation rules if necessary
            return true;
        }

        // Method to validate the password
        public static bool ValidatePassword(string password)
        {
            if (string.IsNullOrEmpty(password))
            {
                return false;
            }
            // Add more validation rules if necessary
            return true;
        }

        // Method to validate the "Remember Me" checkbox
        public static bool ValidateRememberMe(bool rememberMe)
        {
            // No specific validation needed for a checkbox, just return the value
            return rememberMe;
        }

        // Method to encrypt the password
        public static string EncryptPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        // Method to store the login credentials securely
        public static void StoreCredentials(string username, string encryptedPassword, bool rememberMe)
        {
            // Implement secure storage logic here
            // This could involve saving to a secure database or encrypted file
        }

        // Method to validate the login form
        public static bool ValidateLoginForm(string username, string password, bool rememberMe)
        {
            bool isUsernameValid = ValidateUsername(username);
            bool isPasswordValid = ValidatePassword(password);
            bool isRememberMeValid = ValidateRememberMe(rememberMe);

            return isUsernameValid && isPasswordValid && isRememberMeValid;
        }

        // Method to handle the login process
        public static bool HandleLogin(string username, string password, bool rememberMe)
        {
            if (ValidateLoginForm(username, password, rememberMe))
            {
                string encryptedPassword = EncryptPassword(password);
                StoreCredentials(username, encryptedPassword, rememberMe);
                return true;
            }
            return false;
        }
    }
}
