using System;
using System.Collections.Generic;
using System.Linq;

namespace Dotnet4._0.Helpers
{
    public static class CollectionHelper
    {
        /// <summary>
        /// Filters a collection based on a predicate.
        /// </summary>
        /// <typeparam name="T">The type of elements in the collection.</typeparam>
        /// <param name="collection">The collection to filter.</param>
        /// <param name="predicate">The predicate to filter by.</param>
        /// <returns>A filtered collection.</returns>
        public static IEnumerable<T> Filter<T>(IEnumerable<T> collection, Func<T, bool> predicate)
        {
            if (collection == null) throw new ArgumentNullException(nameof(collection));
            if (predicate == null) throw new ArgumentNullException(nameof(predicate));

            return collection.Where(predicate);
        }

        /// <summary>
        /// Sorts a collection based on a key selector.
        /// </summary>
        /// <typeparam name="T">The type of elements in the collection.</typeparam>
        /// <typeparam name="TKey">The type of the key to sort by.</typeparam>
        /// <param name="collection">The collection to sort.</param>
        /// <param name="keySelector">The key selector to sort by.</param>
        /// <param name="ascending">Whether to sort in ascending order.</param>
        /// <returns>A sorted collection.</returns>
        public static IEnumerable<T> Sort<T, TKey>(IEnumerable<T> collection, Func<T, TKey> keySelector, bool ascending = true)
        {
            if (collection == null) throw new ArgumentNullException(nameof(collection));
            if (keySelector == null) throw new ArgumentNullException(nameof(keySelector));

            return ascending ? collection.OrderBy(keySelector) : collection.OrderByDescending(keySelector);
        }

        /// <summary>
        /// Paginates a collection.
        /// </summary>
        /// <typeparam name="T">The type of elements in the collection.</typeparam>
        /// <param name="collection">The collection to paginate.</param>
        /// <param name="pageNumber">The page number to retrieve.</param>
        /// <param name="pageSize">The size of each page.</param>
        /// <returns>A paginated collection.</returns>
        public static IEnumerable<T> Paginate<T>(IEnumerable<T> collection, int pageNumber, int pageSize)
        {
            if (collection == null) throw new ArgumentNullException(nameof(collection));
            if (pageNumber < 1) throw new ArgumentOutOfRangeException(nameof(pageNumber));
            if (pageSize < 1) throw new ArgumentOutOfRangeException(nameof(pageSize));

            return collection.Skip((pageNumber - 1) * pageSize).Take(pageSize);
        }

        /// <summary>
        /// Groups a collection by a key selector.
        /// </summary>
        /// <typeparam name="T">The type of elements in the collection.</typeparam>
        /// <typeparam name="TKey">The type of the key to group by.</typeparam>
        /// <param name="collection">The collection to group.</param>
        /// <param name="keySelector">The key selector to group by.</param>
        /// <returns>A grouped collection.</returns>
        public static IEnumerable<IGrouping<TKey, T>> GroupBy<T, TKey>(IEnumerable<T> collection, Func<T, TKey> keySelector)
        {
            if (collection == null) throw new ArgumentNullException(nameof(collection));
            if (keySelector == null) throw new ArgumentNullException(nameof(keySelector));

            return collection.GroupBy(keySelector);
        }

        /// <summary>
        /// Converts a collection to a dictionary.
        /// </summary>
        /// <typeparam name="T">The type of elements in the collection.</typeparam>
        /// <typeparam name="TKey">The type of the key.</typeparam>
        /// <typeparam name="TValue">The type of the value.</typeparam>
        /// <param name="collection">The collection to convert.</param>
        /// <param name="keySelector">The key selector.</param>
        /// <param name="valueSelector">The value selector.</param>
        /// <returns>A dictionary.</returns>
        public static Dictionary<TKey, TValue> ToDictionary<T, TKey, TValue>(IEnumerable<T> collection, Func<T, TKey> keySelector, Func<T, TValue> valueSelector)
        {
            if (collection == null) throw new ArgumentNullException(nameof(collection));
            if (keySelector == null) throw new ArgumentNullException(nameof(keySelector));
            if (valueSelector == null) throw new ArgumentNullException(nameof(valueSelector));

            return collection.ToDictionary(keySelector, valueSelector);
        }
    }
}
