using System;
using System.Web;

namespace Dotnet4._0.Helpers
{
    public static class UrlHelper
    {
        // Generates a URL for the login page
        public static string GetLoginUrl()
        {
            return "/Account/Login";
        }

        // Generates a URL for the logout page
        public static string GetLogoutUrl()
        {
            return "/Account/Logout";
        }

        // Generates a URL for the registration page
        public static string GetRegisterUrl()
        {
            return "/Account/Register";
        }

        // Generates a URL for the forgot password page
        public static string GetForgotPasswordUrl()
        {
            return "/Account/ForgotPassword";
        }

        // Generates a URL for the reset password page with a token
        public static string GetResetPasswordUrl(string token)
        {
            return $"/Account/ResetPassword?token={HttpUtility.UrlEncode(token)}";
        }

        // Generates a URL for the user profile page
        public static string GetUserProfileUrl(string username)
        {
            return $"/User/Profile?username={HttpUtility.UrlEncode(username)}";
        }

        // Generates a URL for the home page
        public static string GetHomeUrl()
        {
            return "/";
        }

        // Generates a URL for the dashboard page
        public static string GetDashboardUrl()
        {
            return "/Dashboard";
        }

        // Generates a URL for the settings page
        public static string GetSettingsUrl()
        {
            return "/Settings";
        }

        // Generates a URL for the contact us page
        public static string GetContactUsUrl()
        {
            return "/ContactUs";
        }

        // Generates a URL for the about us page
        public static string GetAboutUsUrl()
        {
            return "/AboutUs";
        }

        // Generates a URL for the terms and conditions page
        public static string GetTermsAndConditionsUrl()
        {
            return "/TermsAndConditions";
        }

        // Generates a URL for the privacy policy page
        public static string GetPrivacyPolicyUrl()
        {
            return "/PrivacyPolicy";
        }

        // Generates a URL for the help page
        public static string GetHelpUrl()
        {
            return "/Help";
        }

        // Generates a URL for the FAQ page
        public static string GetFaqUrl()
        {
            return "/FAQ";
        }

        // Generates a URL for the search page with a query
        public static string GetSearchUrl(string query)
        {
            return $"/Search?query={HttpUtility.UrlEncode(query)}";
        }

        // Generates a URL for the notifications page
        public static string GetNotificationsUrl()
        {
            return "/Notifications";
        }

        // Generates a URL for the messages page
        public static string GetMessagesUrl()
        {
            return "/Messages";
        }

        // Generates a URL for the friends page
        public static string GetFriendsUrl()
        {
            return "/Friends";
        }

        // Generates a URL for the groups page
        public static string GetGroupsUrl()
        {
            return "/Groups";
        }

        // Generates a URL for the events page
        public static string GetEventsUrl()
        {
            return "/Events";
        }

        // Generates a URL for the photos page
        public static string GetPhotosUrl()
        {
            return "/Photos";
        }

        // Generates a URL for the videos page
        public static string GetVideosUrl()
        {
            return "/Videos";
        }

        // Generates a URL for the music page
        public static string GetMusicUrl()
        {
            return "/Music";
        }

        // Generates a URL for the blog page
        public static string GetBlogUrl()
        {
            return "/Blog";
        }

        // Generates a URL for the forum page
        public static string GetForumUrl()
        {
            return "/Forum";
        }

        // Generates a URL for the marketplace page
        public static string GetMarketplaceUrl()
        {
            return "/Marketplace";
        }

        // Generates a URL for the jobs page
        public static string GetJobsUrl()
        {
            return "/Jobs";
        }

        // Generates a URL for the classifieds page
        public static string GetClassifiedsUrl()
        {
            return "/Classifieds";
        }

        // Generates a URL for the donations page
        public static string GetDonationsUrl()
        {
            return "/Donations";
        }

        // Generates a URL for the volunteer page
        public static string GetVolunteerUrl()
        {
            return "/Volunteer";
        }

        // Generates a URL for the sponsorship page
        public static string GetSponsorshipUrl()
        {
            return "/Sponsorship";
        }

        // Generates a URL for the testimonials page
        public static string GetTestimonialsUrl()
        {
            return "/Testimonials";
        }

        // Generates a URL for the gallery page
        public static string GetGalleryUrl()
        {
            return "/Gallery";
        }

        // Generates a URL for the news page
        public static string GetNewsUrl()
        {
            return "/News";
        }

        // Generates a URL for the press page
        public static string GetPressUrl()
        {
            return "/Press";
        }

        // Generates a URL for the media page
        public static string GetMediaUrl()
        {
            return "/Media";
        }

        // Generates a URL for the careers page
        public static string GetCareersUrl()
        {
            return "/Careers";
        }

        // Generates a URL for the partners page
        public static string GetPartnersUrl()
        {
            return "/Partners";
        }

        // Generates a URL for the affiliates page
        public static string GetAffiliatesUrl()
        {
            return "/Affiliates";
        }

        // Generates a URL for the sponsors page
        public static string GetSponsorsUrl()
        {
            return "/Sponsors";
        }

        // Generates a URL for the investors page
        public static string GetInvestorsUrl()
        {
            return "/Investors";
        }

        // Generates a URL for the clients page
        public static string GetClientsUrl()
        {
            return "/Clients";
        }

        // Generates a URL for the partners page
        public static string GetPartnersUrl()
        {
            return "/Partners";
        }

        // Generates a URL for the affiliates page
        public static string GetAffiliatesUrl()
        {
            return "/Affiliates";
        }

        // Generates a URL for the sponsors page
        public static string GetSponsorsUrl()
        {
            return "/Sponsors";
        }

        // Generates a URL for the investors page
        public static string GetInvestorsUrl()
        {
            return "/Investors";
        }

        // Generates a URL for the clients page
        public static string GetClientsUrl()
        {
            return "/Clients";
        }
    }
}
