using System;
using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography;
using System.Text;

namespace Dotnet4.0.Models
{
    public class IdentityModels
    {
        public class User
        {
            [Required]
            [StringLength(50, MinimumLength = 3)]
            public string Username { get; set; }

            [Required]
            [StringLength(100, MinimumLength = 6)]
            public string Password { get; set; }

            public bool RememberMe { get; set; }

            public User(string username, string password, bool rememberMe)
            {
                Username = username;
                Password = HashPassword(password);
                RememberMe = rememberMe;
            }

            private string HashPassword(string password)
            {
                using (var sha256 = SHA256.Create())
                {
                    var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                    return BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
                }
            }
        }

        public class LoginModel
        {
            [Required]
            [StringLength(50, MinimumLength = 3)]
            public string Username { get; set; }

            [Required]
            [StringLength(100, MinimumLength = 6)]
            public string Password { get; set; }

            public bool RememberMe { get; set; }
        }

        public class RegisterModel
        {
            [Required]
            [StringLength(50, MinimumLength = 3)]
            public string Username { get; set; }

            [Required]
            [StringLength(100, MinimumLength = 6)]
            public string Password { get; set; }

            [Required]
            [StringLength(100, MinimumLength = 6)]
            [Compare("Password", ErrorMessage = "Passwords do not match.")]
            public string ConfirmPassword { get; set; }
        }

        public class UserService
        {
            public bool ValidateUser(LoginModel loginModel)
            {
                // Simulate user validation logic
                // In a real application, this would involve checking the hashed password against the stored hash in the database
                return true;
            }

            public bool RegisterUser(RegisterModel registerModel)
            {
                // Simulate user registration logic
                // In a real application, this would involve storing the user details in the database
                return true;
            }
        }
    }
}
