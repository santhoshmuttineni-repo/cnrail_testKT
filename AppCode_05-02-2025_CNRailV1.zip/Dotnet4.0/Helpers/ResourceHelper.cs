using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace Dotnet4.0.Helpers
{
    public static class ResourceHelper
    {
        private static readonly string ResourceDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources");

        public static string LoadResource(string resourceName)
        {
            string resourcePath = Path.Combine(ResourceDirectory, resourceName);
            if (!File.Exists(resourcePath))
            {
                throw new FileNotFoundException($"Resource file '{resourceName}' not found.");
            }

            return File.ReadAllText(resourcePath);
        }

        public static Dictionary<string, string> LoadAllResources()
        {
            var resources = new Dictionary<string, string>();
            var resourceFiles = Directory.GetFiles(ResourceDirectory, "*.resx");

            foreach (var resourceFile in resourceFiles)
            {
                var resourceName = Path.GetFileNameWithoutExtension(resourceFile);
                resources[resourceName] = File.ReadAllText(resourceFile);
            }

            return resources;
        }

        public static void SaveResource(string resourceName, string content)
        {
            string resourcePath = Path.Combine(ResourceDirectory, resourceName);
            File.WriteAllText(resourcePath, content);
        }

        public static void DeleteResource(string resourceName)
        {
            string resourcePath = Path.Combine(ResourceDirectory, resourceName);
            if (File.Exists(resourcePath))
            {
                File.Delete(resourcePath);
            }
            else
            {
                throw new FileNotFoundException($"Resource file '{resourceName}' not found.");
            }
        }

        public static bool ResourceExists(string resourceName)
        {
            string resourcePath = Path.Combine(ResourceDirectory, resourceName);
            return File.Exists(resourcePath);
        }

        public static async Task<string> LoadResourceAsync(string resourceName)
        {
            string resourcePath = Path.Combine(ResourceDirectory, resourceName);
            if (!File.Exists(resourcePath))
            {
                throw new FileNotFoundException($"Resource file '{resourceName}' not found.");
            }

            using (var reader = new StreamReader(resourcePath))
            {
                return await reader.ReadToEndAsync();
            }
        }

        public static async Task<Dictionary<string, string>> LoadAllResourcesAsync()
        {
            var resources = new Dictionary<string, string>();
            var resourceFiles = Directory.GetFiles(ResourceDirectory, "*.resx");

            var tasks = resourceFiles.Select(async resourceFile =>
            {
                var resourceName = Path.GetFileNameWithoutExtension(resourceFile);
                using (var reader = new StreamReader(resourceFile))
                {
                    resources[resourceName] = await reader.ReadToEndAsync();
                }
            });

            await Task.WhenAll(tasks);
            return resources;
        }

        public static async Task SaveResourceAsync(string resourceName, string content)
        {
            string resourcePath = Path.Combine(ResourceDirectory, resourceName);
            using (var writer = new StreamWriter(resourcePath))
            {
                await writer.WriteAsync(content);
            }
        }

        public static async Task DeleteResourceAsync(string resourceName)
        {
            string resourcePath = Path.Combine(ResourceDirectory, resourceName);
            if (File.Exists(resourcePath))
            {
                File.Delete(resourcePath);
            }
            else
            {
                throw new FileNotFoundException($"Resource file '{resourceName}' not found.");
            }
        }

        public static async Task<bool> ResourceExistsAsync(string resourceName)
        {
            string resourcePath = Path.Combine(ResourceDirectory, resourceName);
            return await Task.FromResult(File.Exists(resourcePath));
        }
    }
}
