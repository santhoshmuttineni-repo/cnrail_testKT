using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Dotnet4._0.Helpers
{
    public static class CommandHelper
    {
        // Method to validate user input
        public static bool ValidateUserInput(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                return false;
            }

            // Username should be alphanumeric and between 3 to 20 characters
            if (!Regex.IsMatch(username, @"^[a-zA-Z0-9]{3,20}$"))
            {
                return false;
            }

            // Password should be at least 8 characters long and contain at least one number and one special character
            if (password.Length < 8 || !password.Any(char.IsDigit) || !password.Any(ch => !char.IsLetterOrDigit(ch)))
            {
                return false;
            }

            return true;
        }

        // Method to execute a command
        public static bool ExecuteCommand(string command, Dictionary<string, string> parameters)
        {
            try
            {
                // Simulate command execution
                Console.WriteLine($"Executing command: {command}");
                foreach (var param in parameters)
                {
                    Console.WriteLine($"{param.Key}: {param.Value}");
                }

                // Command execution logic goes here
                // For example, interacting with a database or calling an external API

                return true;
            }
            catch (Exception ex)
            {
                // Handle any errors that occur during command execution
                Console.WriteLine($"Error executing command: {ex.Message}");
                return false;
            }
        }

        // Method to handle errors
        public static void HandleError(Exception ex)
        {
            // Log the error (for example, to a file or monitoring system)
            Console.WriteLine($"Error: {ex.Message}");

            // Additional error handling logic can be added here
            // For example, sending an alert or retrying the operation
        }
    }
}
