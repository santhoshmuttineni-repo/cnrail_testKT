using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Dotnet4._0.Helpers
{
    public class ChainOfResponsibilityHelper
    {
        private readonly List<IHandler> _handlers;

        public ChainOfResponsibilityHelper()
        {
            _handlers = new List<IHandler>
            {
                new ValidateInputHandler(),
                new AuthenticateUserHandler(),
                new RememberMeHandler()
            };
        }

        public bool HandleLoginRequest(LoginRequest request)
        {
            foreach (var handler in _handlers)
            {
                if (!handler.Handle(request))
                {
                    return false;
                }
            }
            return true;
        }
    }

    public interface IHandler
    {
        bool Handle(LoginRequest request);
    }

    public class ValidateInputHandler : IHandler
    {
        public bool Handle(LoginRequest request)
        {
            if (string.IsNullOrEmpty(request.Username) || string.IsNullOrEmpty(request.Password))
            {
                return false;
            }
            return true;
        }
    }

    public class AuthenticateUserHandler : IHandler
    {
        public bool Handle(LoginRequest request)
        {
            // Simulate user authentication
            if (request.Username == "admin" && request.Password == "password")
            {
                return true;
            }
            return false;
        }
    }

    public class RememberMeHandler : IHandler
    {
        public bool Handle(LoginRequest request)
        {
            if (request.RememberMe)
            {
                var encryptedCredentials = EncryptCredentials(request.Username, request.Password);
                // Store encrypted credentials securely
                // This is a placeholder for actual storage logic
                Console.WriteLine($"Storing encrypted credentials: {encryptedCredentials}");
            }
            return true;
        }

        private string EncryptCredentials(string username, string password)
        {
            var combined = $"{username}:{password}";
            using (var sha256 = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(combined);
                var hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }
    }

    public class LoginRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public bool RememberMe { get; set; }
    }
}
